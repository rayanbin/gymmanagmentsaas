"use client";

import confetti from "canvas-confetti";

const BLUE = "#3b82f6";
const EMERALD = "#10b981";
const CYAN = "#06b6d4";
const WHITE = "#ffffff";
const AMBER = "#f59e0b";

/** Celebration burst — used on success actions (mark present, scan success, add member). */
export function burstConfetti(x = 0.5, y = 0.5) {
  confetti({
    particleCount: 90,
    spread: 75,
    startVelocity: 42,
    origin: { x, y },
    colors: [BLUE, EMERALD, CYAN, WHITE],
    ticks: 180,
    scalar: 0.95,
    disableForReducedMotion: true,
  });
  // small delayed secondary pop for richness
  window.setTimeout(() => {
    confetti({
      particleCount: 40,
      spread: 100,
      startVelocity: 28,
      origin: { x, y: y + 0.05 },
      colors: [EMERALD, WHITE, AMBER],
      ticks: 150,
      scalar: 0.8,
      disableForReducedMotion: true,
    });
  }, 180);
}

/** Grand burst — role selection / login into dashboard. */
export function grandConfetti() {
  const end = Date.now() + 900;
  const frame = () => {
    confetti({
      particleCount: 5,
      angle: 60,
      spread: 60,
      origin: { x: 0, y: 0.7 },
      colors: [BLUE, CYAN, EMERALD, WHITE],
      disableForReducedMotion: true,
    });
    confetti({
      particleCount: 5,
      angle: 120,
      spread: 60,
      origin: { x: 1, y: 0.7 },
      colors: [BLUE, CYAN, EMERALD, WHITE],
      disableForReducedMotion: true,
    });
    if (Date.now() < end) requestAnimationFrame(frame);
  };
  frame();
}

/** Tiny side spark for row-level checkmarks. */
export function sparkConfetti(x = 0.5, y = 0.6) {
  confetti({
    particleCount: 32,
    spread: 55,
    startVelocity: 34,
    scalar: 0.7,
    ticks: 120,
    origin: { x, y },
    colors: [EMERALD, CYAN, WHITE],
    disableForReducedMotion: true,
  });
}
