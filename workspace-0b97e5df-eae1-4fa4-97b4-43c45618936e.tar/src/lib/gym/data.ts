import type {
  Expense,
  Member,
  ScanEvent,
} from "./types";

export const INITIAL_MEMBERS: Member[] = [
  { id: "MEM-101", name: "Marcus Sterling", phone: "+1 555-0142", email: "marcus.s@pulse.io", plan: "Platinum VIP", fee: 120, status: "Paid", absentDays: 0, presentToday: true, checkInTime: "07:30 AM", method: "Biometric", joined: "2024-01-12" },
  { id: "MEM-104", name: "Ali Khan", phone: "+1 555-0199", email: "ali.k@frontier.co", plan: "Cardio Pro", fee: 85, status: "Pending", absentDays: 4, presentToday: false, checkInTime: null, method: null, joined: "2024-02-03" },
  { id: "MEM-110", name: "David Kim", phone: "+1 555-0210", email: "david.kim@tech.net", plan: "Standard", fee: 60, status: "Paid", absentDays: 0, presentToday: true, checkInTime: "09:02 AM", method: "Biometric", joined: "2024-01-28" },
  { id: "MEM-118", name: "Ahmed Raza", phone: "+1 555-0244", email: "ahmed.r@apex.pk", plan: "Standard", fee: 60, status: "Paid", absentDays: 3, presentToday: false, checkInTime: null, method: null, joined: "2024-03-15" },
  { id: "MEM-182", name: "Sara Jenkins", phone: "+1 555-0312", email: "sara.j@studio.art", plan: "Platinum VIP", fee: 120, status: "Paid", absentDays: 2, presentToday: false, checkInTime: null, method: null, joined: "2024-04-02" },
  { id: "MEM-209", name: "Tariq Rodriguez", phone: "+1 555-0455", email: "tariq.r@fit.com", plan: "Standard", fee: 60, status: "Paid", absentDays: 2, presentToday: false, checkInTime: null, method: null, joined: "2024-05-19" },
  { id: "MEM-091", name: "Elena Morales", phone: "+1 555-0588", email: "elena.m@travel.co", plan: "Cardio Pro", fee: 85, status: "Pending", absentDays: 2, presentToday: false, checkInTime: null, method: null, joined: "2024-06-08" },
  { id: "MEM-144", name: "Jordan Hayes", phone: "+1 555-0671", email: "jordan.h@cloud.org", plan: "Standard", fee: 60, status: "Paid", absentDays: 0, presentToday: false, checkInTime: null, method: null, joined: "2024-07-21" },
  { id: "MEM-155", name: "Chloe Dubois", phone: "+1 555-0789", email: "chloe.d@lux.fr", plan: "Platinum VIP", fee: 120, status: "Paid", absentDays: 1, presentToday: false, checkInTime: null, method: null, joined: "2024-08-11" },
  { id: "MEM-217", name: "Priya Sharma", phone: "+1 555-0821", email: "priya.s@yoga.in", plan: "Cardio Pro", fee: 85, status: "Paid", absentDays: 0, presentToday: false, checkInTime: null, method: null, joined: "2024-09-05" },
];

export const INITIAL_EXPENSES: Expense[] = [
  { id: "EXP-001", category: "Utilities", amount: 1200, date: "2026-09-07", note: "Central HVAC & Power Grid Bill", vendor: "MetroGrid Energy" },
  { id: "EXP-002", category: "Equipment", amount: 850, date: "2026-09-05", note: "Technogym Treadmill Cable & Tensioning", vendor: "Technogym Service" },
  { id: "EXP-003", category: "Supplements", amount: 950, date: "2026-09-03", note: "Optimum Nutrition Gold Whey Cooler Restock", vendor: "SuppHub Wholesale" },
  { id: "EXP-004", category: "Payroll", amount: 1600, date: "2026-08-30", note: "Advance Stipend for PT Instructors", vendor: "Internal Payroll" },
  { id: "EXP-005", category: "Software", amount: 400, date: "2026-08-26", note: "PulseCloud + AWS Biometric Sync Relay", vendor: "AWS Marketplace" },
];

export const REVENUE_TREND: { day: string; revenue: number; checkins: number }[] = [
  { day: "Mon", revenue: 1240, checkins: 118 },
  { day: "Tue", revenue: 1580, checkins: 142 },
  { day: "Wed", revenue: 1310, checkins: 129 },
  { day: "Thu", revenue: 1740, checkins: 156 },
  { day: "Fri", revenue: 1690, checkins: 149 },
  { day: "Sat", revenue: 2120, checkins: 178 },
  { day: "Sun", revenue: 1850, checkins: 164 },
];

export const WEEKLY_FLOWS: { label: string; income: number; expense: number }[] = [
  { label: "W1", income: 3450, expense: 1800 },
  { label: "W2", income: 4120, expense: 1450 },
  { label: "W3", income: 3890, expense: 2050 },
  { label: "W4", income: 4820, expense: 1600 },
];

export const INITIAL_SCAN_EVENTS: ScanEvent[] = [
  { id: "scan-1", memberName: "David Kim", memberId: "MEM-110", confidence: 99.4, plan: "Standard", time: "09:02 AM", success: true },
  { id: "scan-2", memberName: "Marcus Sterling", memberId: "MEM-101", confidence: 99.9, plan: "Platinum VIP", time: "07:30 AM", success: true },
];

export const SCANNER_QUEUE: string[] = [
  "MEM-144", // Jordan Hayes — success
  "MEM-217", // Priya Sharma — success
  "MEM-155", // Chloe Dubois — success
  "MEM-118", // Ahmed Raza — success
  "MEM-182", // Sara Jenkins — success
  "GHOST-777", // unknown fingerprint — failure
  "MEM-209", // Tariq Rodriguez — success
  "MEM-104", // Ali Khan — success
];

export function formatMoney(n: number, decimals = 0): string {
  return `$${n.toLocaleString("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })}`;
}

export function initialsOf(name: string): string {
  return name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}
