export type Role = "owner" | "manager" | "staff";

export type TabId =
  | "dashboard"
  | "members"
  | "attendance"
  | "expenses"
  | "settings";

export type PaymentStatus = "Paid" | "Pending";

export type PlanName = "Standard" | "Cardio Pro" | "Platinum VIP";

export interface Member {
  id: string;
  name: string;
  phone: string;
  email: string;
  plan: PlanName;
  fee: number;
  status: PaymentStatus;
  absentDays: number;
  presentToday: boolean;
  checkInTime: string | null;
  method: "Biometric" | "Manual" | null;
  joined: string;
}

export type ExpenseCategory =
  | "Utilities"
  | "Equipment"
  | "Supplements"
  | "Payroll"
  | "Software";

export interface Expense {
  id: string;
  category: ExpenseCategory;
  amount: number;
  date: string;
  note: string;
  vendor: string;
}

export interface ScanEvent {
  id: string;
  memberName: string;
  memberId: string;
  confidence: number;
  plan: PlanName | string;
  time: string;
  success: boolean;
}

export interface RoleProfile {
  id: Role;
  title: string;
  persona: string;
  subtitle: string;
  tagline: string;
  permissions: string[];
  accent: string;
  glow: string;
  badgeClass: string;
  icon: string;
  gradient: string;
}

export interface RbacMatrix {
  dashboard: "full" | "limited";
  markAttendance: boolean;
  manageMembers: boolean;
  deleteMember: boolean;
  viewExpenses: boolean;
  logExpense: boolean;
  scanner: boolean;
}

export const RBAC: Record<Role, RbacMatrix> = {
  owner: {
    dashboard: "full",
    markAttendance: true,
    manageMembers: true,
    deleteMember: true,
    viewExpenses: true,
    logExpense: true,
    scanner: true,
  },
  manager: {
    dashboard: "full",
    markAttendance: true,
    manageMembers: true,
    deleteMember: false,
    viewExpenses: true,
    logExpense: false,
    scanner: true,
  },
  staff: {
    dashboard: "limited",
    markAttendance: false,
    manageMembers: true,
    deleteMember: false,
    viewExpenses: false,
    logExpense: false,
    scanner: false,
  },
};

export const ROLE_PROFILES: Record<Role, RoleProfile> = {
  owner: {
    id: "owner",
    title: "Owner",
    persona: "Alexandre Vance",
    subtitle: "Club Owner & Founder",
    tagline: "Superadmin — Full Permissions",
    permissions: [
      "Full analytics dashboard & margins",
      "Mark attendance (manual & scanner)",
      "Add members & mutate fee rates",
      "View & log operating expenses",
    ],
    accent: "#10b981",
    glow: "rgba(16,185,129,0.25)",
    badgeClass: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
    icon: "crown",
    gradient: "from-emerald-500 via-emerald-600 to-cyan-600",
  },
  manager: {
    id: "manager",
    title: "Manager",
    persona: "Samantha Reid",
    subtitle: "Floor Operations Manager",
    tagline: "Floor & Attendance Command",
    permissions: [
      "Full analytics dashboard",
      "Mark attendance (manual & scanner)",
      "Add members (fee edits locked)",
      "View expenses (logging locked)",
    ],
    accent: "#3b82f6",
    glow: "rgba(59,130,246,0.25)",
    badgeClass: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    icon: "shield",
    gradient: "from-blue-600 via-indigo-600 to-cyan-500",
  },
  staff: {
    id: "staff",
    title: "Staff",
    persona: "Liam Foster",
    subtitle: "Front Desk Receptionist",
    tagline: "Intake Only — Locked Ops",
    permissions: [
      "Limited dashboard view",
      "Add & view gym members",
      "Attendance marking BLOCKED",
      "Expense ledger BLOCKED",
    ],
    accent: "#f59e0b",
    glow: "rgba(245,158,11,0.25)",
    badgeClass: "bg-amber-500/20 text-amber-400 border-amber-500/30",
    icon: "clipboard",
    gradient: "from-amber-500 via-orange-600 to-rose-500",
  },
};

export const PLAN_FEES: Record<PlanName, number> = {
  Standard: 60,
  "Cardio Pro": 85,
  "Platinum VIP": 120,
};

export const EXPENSE_CATEGORY_META: Record<
  ExpenseCategory,
  { icon: string; color: string; bg: string; border: string }
> = {
  Utilities: {
    icon: "zap",
    color: "text-amber-400",
    bg: "bg-amber-500/15",
    border: "border-amber-500/30",
  },
  Equipment: {
    icon: "wrench",
    color: "text-blue-400",
    bg: "bg-blue-500/15",
    border: "border-blue-500/30",
  },
  Supplements: {
    icon: "dumbbell",
    color: "text-emerald-400",
    bg: "bg-emerald-500/15",
    border: "border-emerald-500/30",
  },
  Payroll: {
    icon: "wallet",
    color: "text-cyan-400",
    bg: "bg-cyan-500/15",
    border: "border-cyan-500/30",
  },
  Software: {
    icon: "cloud",
    color: "text-rose-400",
    bg: "bg-rose-500/15",
    border: "border-rose-500/30",
  },
};

export const TOTAL_INCOME_MTD = 16280;
