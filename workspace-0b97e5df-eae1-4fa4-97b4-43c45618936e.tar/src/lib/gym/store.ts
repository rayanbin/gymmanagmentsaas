"use client";

import { create } from "zustand";
import type {
  Expense,
  Member,
  Role,
  RoleProfile,
  ScanEvent,
  TabId,
} from "./types";
import { ROLE_PROFILES } from "./types";
import {
  INITIAL_EXPENSES,
  INITIAL_MEMBERS,
  INITIAL_SCAN_EVENTS,
} from "./data";

interface GymState {
  /* auth */
  role: Role;
  authenticated: boolean;
  /* nav */
  activeTab: TabId;
  /* data */
  members: Member[];
  expenses: Expense[];
  scanEvents: ScanEvent[];
  /* skeleton demo */
  booting: boolean;

  login: (role: Role) => void;
  logout: () => void;
  setRole: (role: Role) => void;
  setActiveTab: (tab: TabId) => void;
  setBooting: (b: boolean) => void;

  addMember: (m: Member) => void;
  deleteMember: (id: string) => void;
  updateMemberFee: (id: string, fee: number) => void;
  markPresent: (ids: string[], method?: "Manual" | "Biometric") => string;
  resetRosterDay: () => void;

  addExpense: (e: Expense) => void;
  deleteExpense: (id: string) => void;

  pushScanEvent: (e: ScanEvent) => void;
}

function nowTime(): string {
  return new Date().toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
}

export const useGymStore = create<GymState>((set) => ({
  role: "owner",
  authenticated: false,
  activeTab: "dashboard",
  members: INITIAL_MEMBERS,
  expenses: INITIAL_EXPENSES,
  scanEvents: INITIAL_SCAN_EVENTS,
  booting: false,

  login: (role) => set({ role, authenticated: true }),
  logout: () => set({ authenticated: false }),
  setRole: (role) => set({ role }),
  setActiveTab: (tab) => set({ activeTab: tab }),
  setBooting: (b) => set({ booting: b }),

  addMember: (m) => set((s) => ({ members: [m, ...s.members] })),
  deleteMember: (id) =>
    set((s) => ({ members: s.members.filter((m) => m.id !== id) })),
  updateMemberFee: (id, fee) =>
    set((s) => ({
      members: s.members.map((m) => (m.id === id ? { ...m, fee } : m)),
    })),

  markPresent: (ids, method = "Manual") => {
    const time = nowTime();
    set((s) => ({
      members: s.members.map((m) =>
        ids.includes(m.id)
          ? {
              ...m,
              presentToday: true,
              checkInTime: time,
              method,
              absentDays: 0,
            }
          : m,
      ),
    }));
    return time;
  },

  resetRosterDay: () =>
    set((s) => ({
      members: s.members.map((m) =>
        m.method === "Manual" || (m.presentToday && m.method !== "Biometric")
          ? { ...m, presentToday: false, checkInTime: null, method: null }
          : m,
      ),
    })),

  addExpense: (e) => set((s) => ({ expenses: [e, ...s.expenses] })),
  deleteExpense: (id) =>
    set((s) => ({ expenses: s.expenses.filter((e) => e.id !== id) })),

  pushScanEvent: (e) => set((s) => ({ scanEvents: [e, ...s.scanEvents] })),
}));

export function roleProfile(role: Role): RoleProfile {
  return ROLE_PROFILES[role];
}

/** next member id like MEM-### based on max existing */
export function nextMemberId(members: Member[]): string {
  const nums = members.map((m) => parseInt(m.id.replace("MEM-", ""), 10) || 0);
  const max = Math.max(0, ...nums);
  return `MEM-${String(max + 1).padStart(3, "0")}`;
}
