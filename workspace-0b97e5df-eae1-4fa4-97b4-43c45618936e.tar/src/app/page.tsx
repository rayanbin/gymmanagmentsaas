"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

import { AuthScreen } from "@/components/gym/auth-screen";
import { Sidebar } from "@/components/gym/sidebar";
import { Topbar } from "@/components/gym/topbar";
import { DashboardView } from "@/components/gym/dashboard-view";
import { MembersView } from "@/components/gym/members-view";
import { AttendanceView } from "@/components/gym/attendance-view";
import { ExpensesView } from "@/components/gym/expenses-view";
import { SettingsView } from "@/components/gym/settings-view";
import { DashboardSkeleton } from "@/components/gym/skeleton";
import { useGymStore } from "@/lib/gym/store";
import { RBAC, type TabId } from "@/lib/gym/types";
import { grandConfetti } from "@/lib/gym/confetti";

/* Ambient background glow spheres, always present. */
function AmbientGlow() {
  return (
    <>
      <div className="pointer-events-none fixed -z-10 h-[600px] w-[600px] rounded-full bg-blue-600/10 blur-[140px] left-[-5%] top-[-10%]" />
      <div className="pointer-events-none fixed -z-10 h-[700px] w-[700px] rounded-full bg-cyan-600/10 blur-[160px] right-[-5%] bottom-[-10%]" />
      <div className="pointer-events-none fixed -z-10 left-[30%] top-[40%] h-[500px] w-[500px] rounded-full bg-emerald-600/5 blur-[150px]" />
    </>
  );
}

export default function Page() {
  const authenticated = useGymStore((s) => s.authenticated);
  const login = useGymStore((s) => s.login);
  const role = useGymStore((s) => s.role);
  const activeTab = useGymStore((s) => s.activeTab);
  const setActiveTab = useGymStore((s) => s.setActiveTab);
  const booting = useGymStore((s) => s.booting);
  const setBooting = useGymStore((s) => s.setBooting);

  const [mobileNav, setMobileNav] = useState(false);

  /* skeleton shimmer on first boot after login */
  useEffect(() => {
    if (!authenticated) return;
    setBooting(true);
    const t = window.setTimeout(() => setBooting(false), 1100);
    return () => window.clearTimeout(t);
  }, [authenticated, setBooting]);

  /* RBAC: when role loses access to the current tab, migrate gracefully */
  useEffect(() => {
    const rbac = RBAC[role];
    if (activeTab === "attendance" && !rbac.markAttendance) setActiveTab("members");
    if (activeTab === "expenses" && !rbac.viewExpenses) setActiveTab("members");
  }, [role, activeTab, setActiveTab]);

  const handleLogin = (r: Parameters<typeof login>[0]) => {
    grandConfetti();
    login(r);
  };

  return (
    <div className="relative min-h-screen">
      <AmbientGlow />

      <AnimatePresence mode="wait">
        {!authenticated ? (
          <AuthScreen key="auth" onLogin={handleLogin} />
        ) : (
          <motion.div
            key="app"
            initial={{ opacity: 0, scale: 0.985 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="flex min-h-screen flex-col"
          >
            <Topbar onOpenMobileNav={() => setMobileNav(true)} />

            <div className="flex flex-1 gap-0 overflow-x-hidden p-3 sm:p-4 lg:gap-4 lg:p-5">
              <Sidebar mobileOpen={mobileNav} onCloseMobile={() => setMobileNav(false)} />

              <main className="min-w-0 flex-1 space-y-6 pb-8">
                <AnimatePresence mode="wait">
                  {booting ? (
                    <DashboardSkeleton key="skeleton" />
                  ) : (
                    <motion.div
                      key={`${activeTab}-${role}`}
                      initial={{ opacity: 0, y: 18 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -14 }}
                      transition={{ duration: 0.3, ease: "easeInOut" }}
                    >
                      <TabContent activeTab={activeTab} />
                    </motion.div>
                  )}
                </AnimatePresence>
              </main>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function TabContent({ activeTab }: { activeTab: TabId }) {
  switch (activeTab) {
    case "dashboard":
      return (
        <DashboardView
          onNavigate={(t) => {
            const setActiveTab = useGymStore.getState().setActiveTab;
            setActiveTab(t);
          }}
        />
      );
    case "members":
      return <MembersView />;
    case "attendance":
      return <AttendanceView />;
    case "expenses":
      return <ExpensesView />;
    case "settings":
      return <SettingsView />;
    default:
      return null;
  }
}
