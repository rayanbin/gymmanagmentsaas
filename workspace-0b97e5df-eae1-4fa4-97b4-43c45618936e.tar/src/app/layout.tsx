import type { Metadata, Viewport } from "next";
import { Plus_Jakarta_Sans, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const jakarta = Plus_Jakarta_Sans({
  variable: "--font-jakarta",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
});

const jetbrains = JetBrains_Mono({
  variable: "--font-jetbrains",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "PulseForge Elite — Next-Gen Gym Management & Biometrics",
  description:
    "Premium gym management SaaS dashboard with dual-flow biometric attendance, member directory, and real-time P&L ledger.",
  keywords: ["gym management", "SaaS", "dashboard", "biometrics", "attendance"],
  authors: [{ name: "PulseForge Team" }],
};

export const viewport: Viewport = {
  themeColor: "#0a0f1d",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${jakarta.variable} ${jetbrains.variable} antialiased bg-navy-900 text-slate-100`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
