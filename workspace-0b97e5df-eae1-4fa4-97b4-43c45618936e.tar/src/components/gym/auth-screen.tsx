"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Crown,
  Shield,
  ClipboardList,
  Zap,
  Check,
  Lock,
  Sparkles,
  ArrowRight,
  Activity,
  Users,
  Fingerprint,
} from "lucide-react";
import { ROLE_PROFILES, RBAC, type Role } from "@/lib/gym/types";
import { RippleButton } from "./ripple-button";

const ROLE_ICONS = {
  crown: Crown,
  shield: Shield,
  clipboard: ClipboardList,
} as const;

interface AuthScreenProps {
  onLogin: (role: Role) => void;
}

export function AuthScreen({ onLogin }: AuthScreenProps) {
  const [selected, setSelected] = useState<Role | null>(null);
  const [entering, setEntering] = useState(false);

  const roles = Object.values(ROLE_PROFILES);

  const handleEnter = () => {
    if (!selected || entering) return;
    setEntering(true);
    // smooth transition handled by parent AnimatePresence
    window.setTimeout(() => onLogin(selected), 700);
  };

  return (
    <motion.div
      key="auth"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.04, filter: "blur(8px)" }}
      transition={{ duration: 0.45 }}
      className="relative min-h-screen overflow-hidden animated-gradient flex items-center justify-center p-4 sm:p-8"
    >
      {/* ambient glow orbs */}
      <div className="pointer-events-none absolute -top-[12%] left-[8%] h-[480px] w-[480px] rounded-full bg-blue-600/20 blur-[130px]" />
      <div className="pointer-events-none absolute bottom-[-14%] right-[4%] h-[560px] w-[560px] rounded-full bg-cyan-500/15 blur-[150px]" />
      <div className="pointer-events-none absolute top-[36%] left-[55%] h-[380px] w-[380px] rounded-full bg-emerald-500/10 blur-[120px]" />

      {/* faint grid texture */}
      <div className="pointer-events-none absolute inset-0 opacity-[0.07] [background-image:radial-gradient(#60a5fa_1px,transparent_1px)] [background-size:26px_26px]" />

      <div className="relative z-10 w-full max-w-5xl">
        {/* Brand header */}
        <motion.div
          initial={{ opacity: 0, y: -24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="mb-10 text-center"
        >
          <div className="mb-5 inline-flex items-center gap-3">
            <div className="relative">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-500 to-cyan-400 shadow-xl shadow-blue-500/30">
                <Zap className="h-7 w-7 fill-white text-white" />
              </div>
              <span className="absolute -bottom-1 -right-1 h-3.5 w-3.5 rounded-full border-2 border-navy-900 bg-emerald-400" />
            </div>
            <div className="text-left">
              <div className="flex items-center gap-2">
                <span className="bg-gradient-to-r from-white via-slate-100 to-blue-300 bg-clip-text text-3xl font-extrabold tracking-tight text-transparent">
                  PulseForge
                </span>
                <span className="rounded-full border border-blue-500/30 bg-blue-500/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-blue-400">
                  v2.5 SaaS
                </span>
              </div>
              <p className="font-mono text-xs text-slate-400">
                IronPulse Elite Gym Operations
              </p>
            </div>
          </div>

          <motion.h1
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15, duration: 0.5 }}
            className="text-2xl font-bold text-white sm:text-3xl"
          >
            Select Your Access Level
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25, duration: 0.5 }}
            className="mx-auto mt-2 max-w-lg text-sm text-slate-400"
          >
            Simulated RBAC authentication — choose a role to enter the
            operations console with its permission scope.
          </motion.p>
        </motion.div>

        {/* Role cards */}
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
          {roles.map((profile, i) => {
            const Icon = ROLE_ICONS[profile.icon as keyof typeof ROLE_ICONS];
            const isSel = selected === profile.id;
            const rbac = RBAC[profile.id];
            return (
              <motion.div
                key={profile.id}
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  delay: 0.3 + i * 0.1,
                  duration: 0.55,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className="perspective-1200"
              >
                {/* Flip wrapper: rotates on hover (group-hover) and when selected */}
                <motion.div
                  role="button"
                  tabIndex={0}
                  aria-pressed={isSel}
                  onClick={() => setSelected(profile.id)}
                  onKeyDown={(e) =>
                    (e.key === "Enter" || e.key === " ") && setSelected(profile.id)
                  }
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  animate={
                    isSel
                      ? { scale: [1, 1.045, 1] }
                      : { scale: 1 }
                  }
                  transition={
                    isSel
                      ? { duration: 0.55, times: [0, 0.5, 1] }
                      : { type: "spring", stiffness: 300, damping: 22 }
                  }
                  className="group relative h-full cursor-pointer outline-none"
                >
                  {/* selection glow aura */}
                  <AnimatePresence>
                    {isSel && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.94 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.94 }}
                        className="absolute -inset-[3px] rounded-[22px]"
                        style={{
                          background: `linear-gradient(135deg, ${profile.accent}66, transparent 60%, ${profile.accent}44)`,
                          boxShadow: `0 0 34px ${profile.glow}`,
                        }}
                      />
                    )}
                  </AnimatePresence>

                  <div
                    className={`preserve-3d relative h-full transition-transform duration-500 [transition-timing-function:cubic-bezier(0.16,1,0.3,1)] ${
                      isSel ? "rotate-y-180" : "group-hover:rotate-y-180"
                    }`}
                  >
                    {/* ── FRONT ── */}
                    <div className="backface-hidden glass-panel relative flex h-full min-h-[300px] flex-col justify-between rounded-[20px] p-6">
                      <div>
                        <div
                          className={`mb-4 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-tr ${profile.gradient} shadow-lg`}
                        >
                          <Icon className="h-6 w-6 text-white" />
                        </div>
                        <h3 className="text-lg font-bold text-white">
                          {profile.title}
                        </h3>
                        <p className="mt-1 text-xs font-medium" style={{ color: profile.accent }}>
                          {profile.tagline}
                        </p>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-[11px] text-slate-400">
                          <Users className="h-3.5 w-3.5" />
                          {rbac.manageMembers ? "Members: Add / View" : "—"}
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-400">
                          <Fingerprint className="h-3.5 w-3.5" />
                          Attendance:{" "}
                          {rbac.markAttendance ? (
                            <span className="text-emerald-400">Allowed</span>
                          ) : (
                            <span className="text-rose-400">Blocked</span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center justify-between border-t border-white/10 pt-3 text-[10px] font-mono uppercase tracking-wider text-slate-500">
                        <span className="flex items-center gap-1.5">
                          <Sparkles className="h-3 w-3" /> Hover to flip
                        </span>
                        <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                      </div>
                    </div>

                    {/* ── BACK ── */}
                    <div
                      className="backface-hidden rotate-y-180 absolute inset-0 flex h-full flex-col justify-between rounded-[20px] border p-6"
                      style={{
                        background: `linear-gradient(150deg, rgba(15,23,42,0.92), rgba(10,15,29,0.88))`,
                        borderColor: `${profile.accent}55`,
                      }}
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <Icon className="h-4 w-4" style={{ color: profile.accent }} />
                          <span className="font-mono text-[10px] uppercase tracking-widest text-slate-400">
                            Permission Scope
                          </span>
                        </div>
                        <ul className="mt-3 space-y-2.5">
                          {profile.permissions.map((perm) => {
                            const blocked = perm.includes("BLOCKED") || perm.includes("locked") || perm.includes("Locked");
                            return (
                              <li
                                key={perm}
                                className="flex items-start gap-2 text-xs leading-snug"
                              >
                                {blocked ? (
                                  <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-rose-400" />
                                ) : (
                                  <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
                                )}
                                <span className={blocked ? "text-slate-400" : "text-slate-200"}>
                                  {perm}
                                </span>
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                      <div className="border-t border-white/10 pt-3">
                        <div className="text-xs font-bold text-white">
                          {profile.persona}
                        </div>
                        <div className="text-[11px]" style={{ color: profile.accent }}>
                          {profile.subtitle}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* select checkmark badge */}
                  <AnimatePresence>
                    {isSel && (
                      <motion.div
                        initial={{ scale: 0, rotate: -30 }}
                        animate={{ scale: 1, rotate: 0 }}
                        exit={{ scale: 0 }}
                        transition={{ type: "spring", stiffness: 400, damping: 18 }}
                        className={`absolute -right-2 -top-2 flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-tr ${profile.gradient} shadow-lg ring-4 ring-navy-900`}
                      >
                        <Check className="h-4 w-4 text-white" strokeWidth={3.5} />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              </motion.div>
            );
          })}
        </div>

        {/* Enter CTA */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.65, duration: 0.5 }}
          className="mt-8 flex flex-col items-center gap-3"
        >
          <RippleButton
            size="lg"
            className={`w-full max-w-sm text-sm ${
              selected ? "" : "pointer-events-none opacity-40 saturate-50"
            } ${entering ? "scale-105" : ""}`}
            onClick={handleEnter}
            disabled={!selected || entering}
          >
            {entering ? (
              <>
                <motion.span
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 0.9, ease: "linear" }}
                  className="inline-flex"
                >
                  <Activity className="h-4 w-4" />
                </motion.span>
                Establishing Secure Session…
              </>
            ) : (
              <>
                Enter Operations Console
                <ArrowRight className="h-4 w-4" />
              </>
            )}
          </RippleButton>
          <p className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-slate-500">
            <Lock className="h-3 w-3" /> Mock authentication · demo data only
          </p>
        </motion.div>
      </div>
    </motion.div>
  );
}
