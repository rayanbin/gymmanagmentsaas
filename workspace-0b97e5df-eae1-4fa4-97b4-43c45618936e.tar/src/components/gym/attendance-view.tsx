"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ClipboardCheck,
  Scan,
  Search,
  RotateCcw,
  CheckCircle2,
  CheckCheck,
  ShieldAlert,
  Cpu,
  ShieldCheck,
  X,
} from "lucide-react";
import { useGymStore } from "@/lib/gym/store";
import { RBAC } from "@/lib/gym/types";
import { GlassCard, staggerContainer, fadeSlideItem } from "./glass-card";
import { RippleButton } from "./ripple-button";
import { ScannerTerminal } from "./scanner-terminal";
import { initialsOf } from "@/lib/gym/data";
import { cn } from "@/lib/utils";

export function AttendanceView() {
  const [flow, setFlow] = useState<"manual" | "biometric">("manual");
  const role = useGymStore((s) => s.role);
  const rbac = RBAC[role];

  return (
    <motion.div variants={staggerContainer} initial="hidden" animate="show" className="space-y-6">
      {/* Dual flow header */}
      <motion.div
        variants={fadeSlideItem}
        className="glass-card flex flex-col gap-4 rounded-2xl p-4 md:flex-row md:items-center md:justify-between"
      >
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-xl font-bold text-white">Attendance Operations Engine</h2>
            <span className="rounded-full border border-emerald-500/30 bg-emerald-500/15 px-2.5 py-0.5 font-mono text-xs font-bold text-emerald-400">
              Dual-Flow Protocol
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Flow A: Manual Desk Roster (Staff) • Flow B: Physical Biometric Entrance Scanner Terminal
          </p>
        </div>
        <div className="flex items-center rounded-xl border border-white/10 bg-navy-950/80 p-1">
          <FlowTabButton active={flow === "manual"} onClick={() => setFlow("manual")} icon={ClipboardCheck} label="Flow A: Manual Desk Roster" />
          <FlowTabButton
            active={flow === "biometric"}
            onClick={() => rbac.scanner && setFlow("biometric")}
            icon={Scan}
            label="Flow B: Entrance Terminal"
            disabled={!rbac.scanner}
          />
        </div>
      </motion.div>

      {/* RBAC blocked banner for staff */}
      {!rbac.markAttendance && (
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex items-center justify-between gap-4 rounded-xl border border-rose-500/30 bg-rose-500/10 p-4 text-xs text-rose-300"
        >
          <div className="flex items-center gap-3">
            <ShieldAlert className="h-5 w-5 shrink-0 text-rose-400" />
            <div>
              <strong className="font-bold">Access Blocked by RBAC:</strong> Staff role is not authorized
              to register attendance or trigger turnstile overrides. Switch role to{" "}
              <strong>Manager</strong> or <strong>Owner</strong> to authenticate.
            </div>
          </div>
          <span className="hidden shrink-0 rounded bg-rose-500/20 px-2 py-1 font-mono text-[10px] uppercase border border-rose-500/30 sm:block">
            Enforcement Active
          </span>
        </motion.div>
      )}

      <AnimatePresence mode="wait">
        {flow === "manual" ? (
          <motion.div
            key="manual"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          >
            <ManualRoster canMark={rbac.markAttendance} />
          </motion.div>
        ) : (
          <motion.div
            key="biometric"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          >
            <ScannerTerminal />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function FlowTabButton({
  active,
  onClick,
  icon: Icon,
  label,
  disabled,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ElementType;
  label: string;
  disabled?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "relative flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-bold transition",
        disabled && "cursor-not-allowed opacity-40",
      )}
    >
      {active && (
        <motion.span
          layoutId="attendance-flow-pill"
          className="absolute inset-0 rounded-lg bg-blue-600 shadow-md shadow-blue-500/25"
          transition={{ type: "spring", stiffness: 420, damping: 34 }}
        />
      )}
      <span className={cn("relative z-10 flex items-center gap-2", active ? "text-white" : "text-slate-400 hover:text-white")}>
        <Icon className="h-4 w-4" />
        <span className="hidden sm:inline">{label}</span>
        <span className="sm:hidden">{label.split(":")[0]}</span>
      </span>
    </button>
  );
}

/* ───────────────────────── FLOW A: Manual Desk Roster ───────────────────────── */

function ManualRoster({ canMark }: { canMark: boolean }) {
  const members = useGymStore((s) => s.members);
  const markPresent = useGymStore((s) => s.markPresent);
  const resetRosterDay = useGymStore((s) => s.resetRosterDay);

  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [justMarked, setJustMarked] = useState<string[]>([]);

  const list = useMemo(() => {
    const q = query.toLowerCase();
    return members.filter(
      (m) => m.name.toLowerCase().includes(q) || m.id.toLowerCase().includes(q),
    );
  }, [members, query]);

  const markable = list.filter((m) => !m.presentToday);
  const allSelected = markable.length > 0 && markable.every((m) => selected.has(m.id));

  const doMark = (ids: string[], e?: React.MouseEvent) => {
    if (!canMark || ids.length === 0) return;
    markPresent(ids, "Manual");
    setJustMarked(ids);
    window.setTimeout(() => setJustMarked([]), 1400);
    setSelected(new Set());
    if (e) {
      const x = e.clientX / window.innerWidth;
      const y = e.clientY / window.innerHeight;
      // lazy import-free confetti burst from util
      import("@/lib/gym/confetti").then(({ sparkConfetti }) => sparkConfetti(x, y));
    }
  };

  const toggleSelect = (id: string) => {
    setSelected((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <GlassCard hoverLift={false} className="p-5">
      <div className="flex flex-col gap-3 border-b border-white/10 pb-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="flex items-center gap-2 text-sm font-bold text-white">
            Front Desk Daily Attendance Ledger
            <span className="font-normal text-slate-400">(Manager &amp; Owner authorization)</span>
          </h3>
          <p className="text-xs text-slate-400">
            Clicking &lsquo;Mark Present&rsquo; marks member locally and logs check-in timestamp.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="glass-input w-52 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-slate-500 focus:outline-none"
              placeholder="Search roster member…"
              aria-label="Search roster"
            />
          </div>
          <RippleButton variant="outline" size="sm" onClick={resetRosterDay}>
            <RotateCcw className="h-3.5 w-3.5" />
            Reset Day
          </RippleButton>
        </div>
      </div>

      {/* bulk action bar */}
      <AnimatePresence>
        {canMark && selected.size > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            exit={{ opacity: 0, y: -10, height: 0 }}
            className="overflow-hidden"
          >
            <div className="mt-3 flex items-center justify-between rounded-xl border border-blue-500/30 bg-blue-500/10 px-4 py-2.5 text-xs">
              <span className="font-semibold text-blue-300">
                {selected.size} member{selected.size > 1 ? "s" : ""} selected for bulk check-in
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelected(new Set())}
                  className="rounded-lg px-2.5 py-1 font-semibold text-slate-300 hover:bg-slate-800"
                >
                  Clear
                </button>
                <RippleButton size="sm" onClick={() => doMark([...selected])}>
                  <CheckCheck className="h-3.5 w-3.5" />
                  Mark {selected.size} Present
                </RippleButton>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mt-4 overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="text-[10px] uppercase tracking-wider text-slate-400">
            <tr className="border-b border-white/10">
              {canMark && (
                <th className="w-10 px-3 py-3">
                  <AnimatedCheckbox
                    checked={allSelected}
                    onChange={() => {
                      if (allSelected) setSelected(new Set());
                      else setSelected(new Set(markable.map((m) => m.id)));
                    }}
                    label="Select all pending members"
                  />
                </th>
              )}
              <th className="px-3 py-3">Member ID</th>
              <th className="px-3 py-3">Full Name</th>
              <th className="px-3 py-3">Plan</th>
              <th className="px-3 py-3">Status</th>
              <th className="px-3 py-3">Check-in Time</th>
              <th className="px-3 py-3 text-right">Action (RBAC Guarded)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            <AnimatePresence mode="popLayout">
              {list.map((m, i) => {
                const present = m.presentToday;
                const isSelected = selected.has(m.id);
                const justBurst = justMarked.includes(m.id);
                return (
                  <motion.tr
                    key={m.id}
                    layout
                    initial={{ opacity: 0, x: -28 }}
                    animate={{
                      opacity: 1,
                      x: 0,
                      backgroundColor: justBurst
                        ? "rgba(16,185,129,0.16)"
                        : isSelected
                          ? "rgba(59,130,246,0.10)"
                          : "rgba(0,0,0,0)",
                    }}
                    exit={{ opacity: 0, x: 28 }}
                    transition={{ delay: i * 0.04, duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                    className="transition hover:bg-slate-800/40"
                  >
                    {canMark && (
                      <td className="px-3 py-3">
                        {!present && (
                          <AnimatedCheckbox
                            checked={isSelected}
                            onChange={() => toggleSelect(m.id)}
                            label={`Select ${m.name}`}
                          />
                        )}
                      </td>
                    )}
                    <td className="px-3 py-3 font-mono text-slate-400">{m.id}</td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-2.5">
                        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-slate-800 text-[10px] font-bold text-slate-200">
                          {initialsOf(m.name)}
                        </div>
                        <span className="font-bold text-white">{m.name}</span>
                        {/* animated checkmark burst */}
                        <AnimatePresence>
                          {justBurst && (
                            <motion.span
                              initial={{ scale: 0, rotate: -45 }}
                              animate={{ scale: [0, 1.5, 1], rotate: 0 }}
                              exit={{ scale: 0, opacity: 0 }}
                              transition={{ duration: 0.5 }}
                              className="relative inline-flex"
                            >
                              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                              <span className="burst-ring absolute inset-0 rounded-full border-2 border-emerald-400" />
                            </motion.span>
                          )}
                        </AnimatePresence>
                      </div>
                    </td>
                    <td className="px-3 py-3 text-slate-300">{m.plan}</td>
                    <td className="px-3 py-3">
                      {present ? (
                        <motion.span
                          initial={{ scale: 0.85 }}
                          animate={{ scale: 1 }}
                          className="inline-flex items-center gap-1 rounded-md border border-emerald-500/30 bg-emerald-500/20 px-2.5 py-1 text-[11px] font-bold text-emerald-400"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" /> Present
                        </motion.span>
                      ) : (
                        <span className="inline-flex items-center gap-1 rounded-md border border-slate-700 bg-slate-900/80 px-2.5 py-1 text-[11px] font-semibold text-slate-400">
                          Absent
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-3 font-mono text-slate-300">{m.checkInTime ?? "—"}</td>
                    <td className="px-3 py-3 text-right">
                      {present ? (
                        <span className="inline-flex items-center gap-1 font-mono text-[10px] uppercase text-slate-500">
                          Logged · {m.method}
                        </span>
                      ) : canMark ? (
                        <RippleButton
                          size="sm"
                          onClick={(e) => doMark([m.id], e)}
                          className="bg-emerald-500/90 hover:bg-emerald-400"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          Mark Present
                        </RippleButton>
                      ) : (
                        <span className="inline-flex items-center gap-1 rounded border border-white/5 bg-slate-900/80 px-2 py-1 font-mono text-[10px] text-slate-500">
                          <X className="h-3 w-3 text-rose-400" /> Locked (RBAC)
                        </span>
                      )}
                    </td>
                  </motion.tr>
                );
              })}
            </AnimatePresence>
          </tbody>
        </table>
      </div>

      <div className="mt-4 flex items-center justify-between border-t border-white/10 pt-3 text-[11px] text-slate-400">
        <span>
          Today: <strong className="text-emerald-400">{members.filter((m) => m.presentToday).length}</strong> present ·{" "}
          <strong className="text-slate-300">{members.filter((m) => !m.presentToday).length}</strong> absent
        </span>
        <span className="font-mono">Local ledger · syncs on close of day</span>
      </div>
    </GlassCard>
  );
}

/* ───────────────────────── Animated Checkbox ───────────────────────── */

function AnimatedCheckbox({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: () => void;
  label: string;
}) {
  return (
    <motion.button
      type="button"
      role="checkbox"
      aria-checked={checked}
      aria-label={label}
      onClick={(e) => {
        e.stopPropagation();
        onChange();
      }}
      whileTap={{ scale: 0.85 }}
      className={cn(
        "flex h-4.5 w-4.5 items-center justify-center rounded-md border transition-colors duration-200",
        checked ? "border-blue-500 bg-blue-600" : "border-slate-600 bg-slate-900/80 hover:border-blue-400",
      )}
      style={{ width: 18, height: 18 }}
    >
      <AnimatePresence>
        {checked && (
          <motion.svg
            initial={{ scale: 0, rotate: -30 }}
            animate={{ scale: 1, rotate: 0 }}
            exit={{ scale: 0 }}
            transition={{ type: "spring", stiffness: 500, damping: 22 }}
            width="11"
            height="11"
            viewBox="0 0 12 12"
            fill="none"
          >
            <path d="M2 6.5L4.7 9L10 3" stroke="white" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
          </motion.svg>
        )}
      </AnimatePresence>
    </motion.button>
  );
}

/* ───────────────────────── Hardware Match Stream (shared by scanner) ───────────────────────── */

export function AuditStreamFooter() {
  return (
    <div className="mt-4 flex items-center justify-between border-t border-white/10 pt-3 text-[11px] text-slate-400">
      <span>Relay Port 1: Hydraulic Turnstile (3.5s)</span>
      <span className="flex items-center gap-1 font-mono text-emerald-400">
        <ShieldCheck className="h-3.5 w-3.5" /> Encrypted
      </span>
    </div>
  );
}

export function ScanAuditHeader() {
  return (
    <div className="flex items-center justify-between border-b border-white/10 pb-3">
      <div className="flex items-center gap-2">
        <Cpu className="h-4 w-4 text-emerald-400" />
        <h3 className="text-sm font-bold text-white">Hardware Match Stream</h3>
      </div>
      <span className="font-mono text-[10px] text-slate-400">AES-256 Verified</span>
    </div>
  );
}
