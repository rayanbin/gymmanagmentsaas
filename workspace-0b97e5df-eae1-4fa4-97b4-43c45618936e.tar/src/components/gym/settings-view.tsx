"use client";

import { motion } from "framer-motion";
import { Shield, Check, X, Minus, Crown, ShieldHalf, ClipboardList } from "lucide-react";
import { RBAC, ROLE_PROFILES, type Role, type TabId } from "@/lib/gym/types";
import { useGymStore } from "@/lib/gym/store";
import { GlassCard, staggerContainer, fadeSlideItem } from "./glass-card";
import { cn } from "@/lib/utils";

type MatrixRow = {
  label: string;
  desc: string;
  get: (r: Role) => string | boolean;
};

const ROWS: MatrixRow[] = [
  {
    label: "Full Analytics Dashboard & Margins",
    desc: "Revenue velocity, retention risk, capacity telemetry",
    get: (r) => (RBAC[r].dashboard === "full" ? "Full" : "Limited View"),
  },
  {
    label: "Mark Attendance (Manual & Scanner)",
    desc: "Desk roster check-ins and turnstile overrides",
    get: (r) => RBAC[r].markAttendance,
  },
  {
    label: "Add & View Gym Members",
    desc: "Front-desk intake and roster browsing",
    get: () => true,
  },
  {
    label: "Delete Member / Mutate Fee Rates",
    desc: "Subscription pricing and roster removal",
    get: (r) => (RBAC[r].deleteMember ? "Full" : false),
  },
  {
    label: "View Operating Expenses",
    desc: "Read-only P&L ledger access",
    get: (r) => RBAC[r].viewExpenses,
  },
  {
    label: "Log Gym Expenses",
    desc: "Record disbursements into the ledger",
    get: (r) => RBAC[r].logExpense,
  },
];

function Cell({ value }: { value: string | boolean }) {
  const cls =
    value === true || value === "Full"
      ? "text-emerald-400 font-bold"
      : value === "Limited View"
        ? "text-amber-400 font-medium"
        : "text-rose-400 font-bold";
  return (
    <span className={cn("flex items-center gap-1.5", cls)}>
      {value === true || value === "Full" ? (
        <Check className="h-3.5 w-3.5" />
      ) : value === "Limited View" ? (
        <Minus className="h-3.5 w-3.5" />
      ) : (
        <X className="h-3.5 w-3.5" />
      )}
      {value === true ? "Allowed" : typeof value === "string" ? value : "BLOCKED"}
    </span>
  );
}

export function SettingsView() {
  const role = useGymStore((s) => s.role);
  const roles: Role[] = ["owner", "manager", "staff"];
  const RoleIcon = { owner: Crown, manager: ShieldHalf, staff: ClipboardList } as const;

  return (
    <motion.div variants={staggerContainer} initial="hidden" animate="show" className="space-y-6">
      <motion.div variants={fadeSlideItem}>
        <h2 className="flex flex-wrap items-center gap-2 text-xl font-bold text-white">
          Role-Based Access Control (RBAC) Architecture
          <span className="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-0.5 font-mono text-xs text-emerald-400">
            Strict Specification
          </span>
        </h2>
        <p className="mt-1 text-xs text-slate-400">
          Verification matrix reflecting client/server RBAC permission enforcement.
        </p>
      </motion.div>

      <GlassCard variants={fadeSlideItem} hoverLift={false} className="p-6 shadow-2xl">
        <h3 className="mb-4 flex items-center gap-2 text-sm font-bold text-white">
          <Shield className="h-4 w-4 text-blue-400" />
          Permission Policy Matrix vs. Current Active Session
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-[10px] uppercase tracking-wider text-slate-400">
              <tr className="border-b border-white/10">
                <th className="py-3 pr-4">Module / Action</th>
                {roles.map((r) => (
                  <th key={r} className="py-3 pr-4">
                    <span className="flex items-center gap-1.5">
                      {(() => {
                        const Icon = RoleIcon[r];
                        return <Icon className="h-3.5 w-3.5" style={{ color: ROLE_PROFILES[r].accent }} />;
                      })()}
                      {ROLE_PROFILES[r].title}
                    </span>
                  </th>
                ))}
                <th className="py-3 text-right">Active Session State</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {ROWS.map((row, i) => {
                const current = row.get(role);
                const allowed = current === true || current === "Full" || current === "Limited View";
                return (
                  <motion.tr
                    key={row.label}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.06 }}
                    className="transition hover:bg-slate-800/30"
                  >
                    <td className="py-3 pr-4">
                      <div className="font-semibold text-white">{row.label}</div>
                      <div className="text-[10px] text-slate-500">{row.desc}</div>
                    </td>
                    {roles.map((r) => (
                      <td key={r} className="py-3 pr-4">
                        <Cell value={row.get(r)} />
                      </td>
                    ))}
                    <td className="py-3 text-right">
                      <motion.span
                        key={`${row.label}-${role}`}
                        initial={{ scale: 0.85, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        className={cn(
                          "inline-block rounded-md px-2.5 py-1 text-[11px] font-bold",
                          allowed
                            ? "bg-emerald-500/20 text-emerald-400"
                            : "bg-rose-500/20 text-rose-400",
                        )}
                      >
                        {allowed ? "Allowed" : "Blocked"}
                      </motion.span>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="mt-6 rounded-xl border border-white/10 bg-slate-900/90 p-4 text-xs text-slate-300">
          <span className="mb-1 block font-bold text-white">Instant RBAC Verification Instruction:</span>
          <p className="leading-relaxed text-slate-400">
            Switch the top-bar dropdown role to <strong className="text-amber-300">Staff</strong>. Notice the{" "}
            <em>Attendance</em> navigation button locks with a warning, the <em>Mark Present</em> actions in the
            roster are replaced with locked badges, and the <em>Expense Log</em> button is guarded. Switch back to{" "}
            <strong className="text-blue-300">Manager</strong> or <strong className="text-emerald-300">Owner</strong>{" "}
            to restore authorized flows instantly — UI elements cross-fade to reflect the new permission scope.
          </p>
        </div>
      </GlassCard>
    </motion.div>
  );
}
