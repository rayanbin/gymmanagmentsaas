"use client";

import { motion } from "framer-motion";
import {
  LayoutDashboard,
  Users,
  Fingerprint,
  Receipt,
  Settings2,
  MapPin,
  Lock,
  LogOut,
  Zap,
} from "lucide-react";
import { RBAC, type Role, type TabId } from "@/lib/gym/types";
import { useGymStore } from "@/lib/gym/store";
import { cn } from "@/lib/utils";

interface NavItem {
  id: TabId;
  label: string;
  icon: React.ElementType;
  badge: string;
  badgeClass: string;
}

const NAV_ITEMS: NavItem[] = [
  {
    id: "dashboard",
    label: "Dashboard",
    icon: LayoutDashboard,
    badge: "Live",
    badgeClass: "bg-blue-400/20 text-blue-200",
  },
  {
    id: "members",
    label: "Members",
    icon: Users,
    badge: "10",
    badgeClass: "bg-slate-800 text-slate-400",
  },
  {
    id: "attendance",
    label: "Attendance",
    icon: Fingerprint,
    badge: "Dual-Flow",
    badgeClass: "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20",
  },
  {
    id: "expenses",
    label: "Expense & P&L",
    icon: Receipt,
    badge: "Ledger",
    badgeClass: "bg-amber-500/10 text-amber-400 border border-amber-500/20",
  },
  {
    id: "settings",
    label: "Settings & Policy",
    icon: Settings2,
    badge: "RBAC",
    badgeClass: "bg-slate-800 text-slate-400",
  },
];

interface SidebarProps {
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export function Sidebar({ mobileOpen, onCloseMobile }: SidebarProps) {
  const activeTab = useGymStore((s) => s.activeTab);
  const setActiveTab = useGymStore((s) => s.setActiveTab);
  const role = useGymStore((s) => s.role);
  const logout = useGymStore((s) => s.logout);
  const memberCount = useGymStore((s) => s.members.length);

  const canAccess = (id: TabId) =>
    id !== "attendance" || RBAC[role].markAttendance;
  const canView = (id: TabId) =>
    id !== "expenses" || RBAC[role].viewExpenses;

  const navigate = (id: TabId) => {
    if (!canAccess(id) || !canView(id)) return;
    setActiveTab(id);
    onCloseMobile();
  };

  const items = NAV_ITEMS.map((item) => ({
    ...item,
    badge: item.id === "members" ? String(memberCount) : item.badge,
    locked: !canAccess(item.id) || !canView(item.id),
  }));

  return (
    <>
      {/* mobile backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      <motion.aside
        initial={{ x: -280, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className={cn(
          "glass-panel fixed inset-y-0 left-0 z-50 flex w-64 shrink-0 select-none flex-col justify-between rounded-r-2xl p-4 transition-transform duration-300 lg:static lg:z-20 lg:translate-x-0 lg:rounded-2xl",
          mobileOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div>
          {/* Branch card */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="mb-6 flex items-center gap-3 rounded-2xl border border-white/10 bg-gradient-to-r from-slate-900/90 to-blue-950/40 p-3.5 shadow-lg"
          >
            <div className="rounded-xl border border-blue-500/25 bg-blue-500/15 p-2.5 text-blue-400">
              <MapPin className="h-4 w-4" />
            </div>
            <div className="overflow-hidden">
              <div className="truncate text-xs font-bold text-white">
                Metro Downtown Apex
              </div>
              <div className="flex items-center gap-1 font-mono text-[10px] text-slate-400">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                Live Sensor: 48 in Gym
              </div>
            </div>
          </motion.div>

          {/* Nav */}
          <nav className="space-y-1.5" aria-label="Primary">
            {items.map((item, i) => {
              const active = activeTab === item.id;
              return (
                <motion.button
                  key={item.id}
                  initial={{ opacity: 0, x: -18 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 + i * 0.07 }}
                  onClick={() => navigate(item.id)}
                  title={item.locked ? "Restricted for current role" : item.label}
                  className={cn(
                    "group relative flex w-full items-center justify-between rounded-xl px-3.5 py-2.5 text-xs font-semibold transition-colors duration-200",
                    active
                      ? "text-white"
                      : item.locked
                        ? "text-slate-500"
                        : "text-slate-400 hover:text-white",
                    item.locked ? "cursor-not-allowed" : "cursor-pointer",
                  )}
                >
                  {/* sliding active indicator */}
                  {active && (
                    <motion.span
                      layoutId="sidebar-active-pill"
                      transition={{ type: "spring", stiffness: 420, damping: 34 }}
                      className="absolute inset-0 rounded-xl border border-blue-400/30 bg-blue-600 shadow-lg shadow-blue-500/25"
                    />
                  )}
                  {/* hover glow */}
                  {!active && !item.locked && (
                    <span className="absolute inset-0 rounded-xl opacity-0 transition-opacity duration-200 group-hover:opacity-100 group-hover:shadow-[0_0_18px_rgba(59,130,246,0.25),inset_0_0_12px_rgba(59,130,246,0.08)] group-hover:bg-slate-800/60" />
                  )}

                  <span className="relative z-10 flex items-center gap-3">
                    <item.icon
                      className={cn(
                        "h-4 w-4 transition-all duration-200",
                        !active && !item.locked && "group-hover:text-blue-300 group-hover:drop-shadow-[0_0_6px_rgba(96,165,250,0.8)]",
                        active && "text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.45)]",
                      )}
                    />
                    <span className="flex items-center gap-1.5">
                      {item.label}
                      {item.locked && <Lock className="h-3 w-3 text-rose-400/80" />}
                    </span>
                  </span>
                  <span
                    className={cn(
                      "relative z-10 rounded px-1.5 py-0.5 font-mono text-[10px]",
                      item.badgeClass,
                    )}
                  >
                    {item.locked ? "Locked" : item.badge}
                  </span>
                </motion.button>
              );
            })}
          </nav>
        </div>

        {/* RBAC status footer */}
        <SidebarFooter onLogout={logout} />
      </motion.aside>
    </>
  );
}

function SidebarFooter({ onLogout }: { onLogout: () => void }) {
  const role = useGymStore((s) => s.role);
  const profile = {
    owner: {
      pill: "OWNER",
      cls: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
      desc: "Full permissions active. Can mutate membership rates, manage expenses, and operate biometric hardware.",
    },
    manager: {
      pill: "MANAGER",
      cls: "bg-blue-500/20 text-blue-400 border-blue-500/30",
      desc: "Manager mode: allowed to register attendance & view expenses. Membership price alterations restricted.",
    },
    staff: {
      pill: "STAFF",
      cls: "bg-amber-500/20 text-amber-400 border-amber-500/30",
      desc: "Front-desk intake only. Attendance and financial mutation locked by policy.",
    },
  }[role];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.5 }}
      className="glass-card rounded-2xl p-3.5"
    >
      <div className="mb-2 flex items-center justify-between">
        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
          RBAC Enforcement
        </span>
        <span
          className={cn(
            "rounded-full border px-2 py-0.5 text-[10px] font-bold",
            profile.cls,
          )}
        >
          {profile.pill}
        </span>
      </div>
      <p className="text-[11px] leading-relaxed text-slate-400">
        {profile.desc}
      </p>
      <button
        onClick={onLogout}
        className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-lg border border-white/10 bg-slate-800/60 py-1.5 text-[11px] font-semibold text-slate-300 transition hover:bg-rose-500/15 hover:text-rose-300"
      >
        <LogOut className="h-3 w-3" /> Sign out · Switch role
      </button>
      <div className="mt-2.5 flex items-center justify-center gap-1.5 font-mono text-[9px] uppercase tracking-widest text-slate-600">
        <Zap className="h-2.5 w-2.5" /> PulseForge Secure Core
      </div>
    </motion.div>
  );
}

export function useRole(): { role: Role } {
  const role = useGymStore((s) => s.role);
  return { role };
}
