"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  UserPlus,
  Check,
  AlertTriangle,
  Pencil,
  Trash2,
  Lock,
  LayoutGrid,
  Rows3,
  X,
  Mail,
  Phone,
  CalendarDays,
  Fingerprint,
  CreditCard,
} from "lucide-react";
import { useGymStore, nextMemberId } from "@/lib/gym/store";
import { RBAC, PLAN_FEES, type Member, type PlanName, type PaymentStatus } from "@/lib/gym/types";
import { GlassCard, staggerContainer, fadeSlideItem } from "./glass-card";
import { RippleButton } from "./ripple-button";
import { formatMoney, initialsOf } from "@/lib/gym/data";
import { burstConfetti } from "@/lib/gym/confetti";
import { cn } from "@/lib/utils";

export function MembersView() {
  const members = useGymStore((s) => s.members);
  const addMember = useGymStore((s) => s.addMember);
  const deleteMemberFn = useGymStore((s) => s.deleteMember);
  const updateMemberFee = useGymStore((s) => s.updateMemberFee);
  const role = useGymStore((s) => s.role);
  const rbac = RBAC[role];

  const [query, setQuery] = useState("");
  const [focused, setFocused] = useState(false);
  const [filter, setFilter] = useState<"all" | PaymentStatus>("all");
  const [view, setView] = useState<"table" | "cards">("table");
  const [modalOpen, setModalOpen] = useState(false);
  const [editingFee, setEditingFee] = useState<string | null>(null);
  const [feeDraft, setFeeDraft] = useState(0);

  const list = useMemo(() => {
    const q = query.toLowerCase();
    return members.filter(
      (m) =>
        (m.name.toLowerCase().includes(q) ||
          m.id.toLowerCase().includes(q) ||
          m.email.toLowerCase().includes(q)) &&
        (filter === "all" || m.status === filter),
    );
  }, [members, query, filter]);

  const handleAdd = (m: Omit<Member, "id">) => {
    addMember({ ...m, id: nextMemberId(members) });
    setModalOpen(false);
    burstConfetti(0.5, 0.55);
  };

  const handleDelete = (id: string) => {
    deleteMemberFn(id);
  };

  return (
    <motion.div variants={staggerContainer} initial="hidden" animate="show" className="space-y-6">
      {/* Header */}
      <motion.div variants={fadeSlideItem} className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="flex flex-wrap items-center gap-2 text-xl font-bold text-white">
            Member Directory &amp; Subscription Ledger
            <span className="rounded-full border border-blue-500/20 bg-blue-500/10 px-2.5 py-0.5 font-mono text-xs text-blue-400">
              Encrypted Store
            </span>
          </h2>
          <p className="mt-1 text-xs text-slate-400">
            Active gym member roster, recurring billing state, biometrics registry, and role-governed actions.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          {/* search with smooth focus effect */}
          <motion.div
            animate={{
              scale: focused ? 1.04 : 1,
              boxShadow: focused ? "0 0 22px rgba(59,130,246,0.25)" : "0 0 0px rgba(59,130,246,0)",
            }}
            className="relative rounded-xl"
          >
            <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onFocus={() => setFocused(true)}
              onBlur={() => setFocused(false)}
              className="glass-input w-56 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-slate-500 focus:outline-none sm:w-60"
              placeholder="Search name, ID, phone…"
              aria-label="Search members"
            />
            {query && (
              <button
                onClick={() => setQuery("")}
                className="absolute right-2.5 top-2.5 text-slate-500 hover:text-white"
                aria-label="Clear search"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </motion.div>

          {/* filter pills */}
          <div className="flex items-center rounded-xl border border-white/10 bg-slate-900/80 p-1 text-xs">
            {(["all", "Paid", "Pending"] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={cn(
                  "relative rounded-lg px-2.5 py-1 font-semibold transition",
                  filter === f ? "text-blue-400" : "text-slate-400 hover:text-white",
                )}
              >
                {filter === f && (
                  <motion.span
                    layoutId="member-filter-pill"
                    className="absolute inset-0 rounded-lg bg-blue-500/20"
                    transition={{ type: "spring", stiffness: 420, damping: 32 }}
                  />
                )}
                <span className="relative z-10">{f === "all" ? "All" : f === "Paid" ? "Paid" : "Overdue"}</span>
              </button>
            ))}
          </div>

          {/* view toggle */}
          <div className="flex items-center rounded-xl border border-white/10 bg-slate-900/80 p-1">
            <button
              onClick={() => setView("table")}
              className={cn("rounded-lg p-1.5 transition", view === "table" ? "bg-blue-500/20 text-blue-400" : "text-slate-400 hover:text-white")}
              aria-label="Table view"
            >
              <Rows3 className="h-4 w-4" />
            </button>
            <button
              onClick={() => setView("cards")}
              className={cn("rounded-lg p-1.5 transition", view === "cards" ? "bg-blue-500/20 text-blue-400" : "text-slate-400 hover:text-white")}
              aria-label="Card view"
            >
              <LayoutGrid className="h-4 w-4" />
            </button>
          </div>

          <RippleButton variant="success" onClick={() => setModalOpen(true)}>
            <UserPlus className="h-4 w-4" />
            Add Member
          </RippleButton>
        </div>
      </motion.div>

      {/* Content */}
      {view === "table" ? (
        <GlassCard variants={fadeSlideItem} hoverLift={false} className="overflow-hidden shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-white/10 bg-slate-900/90 text-[10px] uppercase tracking-wider text-slate-400">
                <tr>
                  <th className="px-4 py-3.5">Member Info</th>
                  <th className="px-4 py-3.5">Plan &amp; Rate</th>
                  <th className="px-4 py-3.5">Contact Details</th>
                  <th className="px-4 py-3.5">Payment Status</th>
                  <th className="px-4 py-3.5">Attendance Streak</th>
                  <th className="px-4 py-3.5 text-right">Actions (Role Guard)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                <AnimatePresence mode="popLayout">
                  {list.map((m, i) => (
                    <motion.tr
                      key={m.id}
                      layout
                      initial={{ opacity: 0, y: 14 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -32 }}
                      transition={{ delay: i * 0.05, duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                      className="group transition hover:bg-slate-800/40"
                    >
                      <td className="px-4 py-3.5">
                        <div className="flex items-center gap-3">
                          <div className="flex h-8 w-8 items-center justify-center rounded-xl border border-white/10 bg-gradient-to-tr from-slate-800 to-slate-700 text-xs font-bold text-white shadow-sm">
                            {initialsOf(m.name)}
                          </div>
                          <div>
                            <div className="font-bold text-white transition-colors group-hover:text-blue-400">
                              {m.name}
                            </div>
                            <div className="font-mono text-[10px] text-slate-500">{m.id}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3.5">
                        {editingFee === m.id && rbac.deleteMember ? (
                          <FeeEditor
                            fee={feeDraft}
                            onChange={setFeeDraft}
                            onSave={() => {
                              updateMemberFee(m.id, feeDraft);
                              setEditingFee(null);
                            }}
                            onCancel={() => setEditingFee(null)}
                          />
                        ) : (
                          <>
                            <div className="font-semibold text-slate-200">{m.plan}</div>
                            <div className="font-mono text-[10px] text-slate-400">{formatMoney(m.fee)} / month</div>
                          </>
                        )}
                      </td>
                      <td className="px-4 py-3.5 text-slate-400">
                        <div>{m.phone}</div>
                        <div className="text-[10px] text-slate-500">{m.email}</div>
                      </td>
                      <td className="px-4 py-3.5">
                        {m.status === "Paid" ? (
                          <span className="inline-flex items-center gap-1 rounded-full border border-emerald-500/25 bg-emerald-500/15 px-2.5 py-0.5 text-[11px] font-bold text-emerald-400">
                            <Check className="h-3 w-3" /> Paid
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 rounded-full border border-rose-500/25 bg-rose-500/15 px-2.5 py-0.5 text-[11px] font-bold text-rose-400">
                            <AlertTriangle className="h-3 w-3" /> Overdue ({formatMoney(m.fee)})
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3.5">
                        {m.absentDays > 0 ? (
                          <span className="font-mono font-bold text-rose-400">Absent {m.absentDays}d</span>
                        ) : m.presentToday ? (
                          <span className="font-mono font-bold text-emerald-400">Active (Today)</span>
                        ) : (
                          <span className="font-mono font-bold text-slate-400">Rest Day</span>
                        )}
                      </td>
                      <td className="px-4 py-3.5 text-right">
                        {rbac.deleteMember ? (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => {
                                setEditingFee(m.id);
                                setFeeDraft(m.fee);
                              }}
                              className="rounded-lg p-1.5 text-slate-400 transition hover:bg-slate-800 hover:text-blue-400"
                              title="Modify Membership Rate"
                            >
                              <Pencil className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => handleDelete(m.id)}
                              className="rounded-lg p-1.5 text-slate-400 transition hover:bg-slate-800 hover:text-rose-400"
                              title="Delete Member"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        ) : (
                          <span className="inline-flex items-center gap-1 rounded border border-white/5 bg-slate-900/80 px-2 py-1 font-mono text-[10px] text-slate-500">
                            <Lock className="h-3 w-3" />
                            {role === "manager" ? "Mutate Locked (Mgr)" : "Read-Only (FrontDesk)"}
                          </span>
                        )}
                      </td>
                    </motion.tr>
                  ))}
                </AnimatePresence>
                {list.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-4 py-10 text-center text-slate-500">
                      No members match “{query}”.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </GlassCard>
      ) : (
        /* ── FLIP CARD GRID ── */
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          <AnimatePresence mode="popLayout">
            {list.map((m, i) => (
              <FlipMemberCard
                key={m.id}
                member={m}
                index={i}
                canDelete={rbac.deleteMember}
                onDelete={handleDelete}
              />
            ))}
          </AnimatePresence>
        </div>
      )}

      <AddMemberModal open={modalOpen} onClose={() => setModalOpen(false)} onAdd={handleAdd} />
    </motion.div>
  );
}

function FeeEditor({
  fee,
  onChange,
  onSave,
  onCancel,
}: {
  fee: number;
  onChange: (n: number) => void;
  onSave: () => void;
  onCancel: () => void;
}) {
  return (
    <motion.div initial={{ opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1 }} className="flex items-center gap-1.5">
      <input
        type="number"
        value={fee}
        onChange={(e) => onChange(Number(e.target.value))}
        className="glass-input w-20 rounded-lg px-2 py-1 font-mono text-xs text-white focus:outline-none"
        autoFocus
      />
      <button onClick={onSave} className="rounded-lg bg-emerald-500/20 p-1 text-emerald-400 hover:bg-emerald-500/30" title="Save rate">
        <Check className="h-3.5 w-3.5" />
      </button>
      <button onClick={onCancel} className="rounded-lg bg-slate-800 p-1 text-slate-400 hover:text-white" title="Cancel">
        <X className="h-3.5 w-3.5" />
      </button>
    </motion.div>
  );
}

/* ───────────────────────── Flip Member Card ───────────────────────── */

function FlipMemberCard({
  member,
  index,
  canDelete,
  onDelete,
}: {
  member: Member;
  index: number;
  canDelete: boolean;
  onDelete: (id: string) => void;
}) {
  const [flipped, setFlipped] = useState(false);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 26 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.92 }}
      transition={{ delay: index * 0.06, duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      className="perspective-1200"
    >
      <motion.button
        onClick={() => setFlipped((f) => !f)}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className="group relative block w-full text-left outline-none"
        aria-pressed={flipped}
      >
        <motion.div
          animate={{ rotateY: flipped ? 180 : 0 }}
          transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
          className="preserve-3d relative h-56 w-full"
        >
          {/* FRONT — photo / name */}
          <div
            className={cn(
              "backface-hidden glass-card absolute inset-0 flex flex-col items-center justify-center rounded-2xl p-5 text-center",
              flipped && "pointer-events-none",
            )}
          >
            <div className="relative mb-3">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-500 to-cyan-400 text-xl font-black text-white shadow-lg shadow-blue-500/25">
                {initialsOf(member.name)}
              </div>
              <span
                className={cn(
                  "absolute -bottom-1 -right-1 h-4 w-4 rounded-full border-2 border-navy-900",
                  member.status === "Paid" ? "bg-emerald-400" : "bg-rose-500",
                )}
              />
            </div>
            <div className="text-sm font-bold text-white">{member.name}</div>
            <div className="font-mono text-[10px] text-slate-500">#{member.id}</div>
            <div className="mt-2 rounded-full border border-blue-500/25 bg-blue-500/10 px-2.5 py-0.5 text-[10px] font-semibold text-blue-300">
              {member.plan} · {formatMoney(member.fee)}/mo
            </div>
            <div className="mt-3 flex items-center gap-1.5 text-[10px] font-medium text-slate-500">
              <LayoutGrid className="h-3 w-3" /> Tap to reveal details
            </div>
          </div>

          {/* BACK — details */}
          <div
            className={cn(
              "backface-hidden rotate-y-180 absolute inset-0 flex flex-col justify-between rounded-2xl border border-blue-500/25 bg-gradient-to-br from-navy-850/95 to-navy-950/95 p-4",
              !flipped && "pointer-events-none",
            )}
          >
            <div>
              <div className="flex items-center justify-between">
                <div className="text-sm font-bold text-white">{member.name}</div>
                <span
                  className={cn(
                    "rounded-full border px-2 py-0.5 text-[9px] font-bold uppercase",
                    member.status === "Paid"
                      ? "border-emerald-500/25 bg-emerald-500/15 text-emerald-400"
                      : "border-rose-500/25 bg-rose-500/15 text-rose-400",
                  )}
                >
                  {member.status}
                </span>
              </div>
              <div className="mt-3 space-y-2 text-[11px] text-slate-300">
                <div className="flex items-center gap-2">
                  <Mail className="h-3 w-3 text-blue-400" />
                  <span className="truncate">{member.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-3 w-3 text-cyan-400" />
                  {member.phone}
                </div>
                <div className="flex items-center gap-2">
                  <CalendarDays className="h-3 w-3 text-amber-400" />
                  Joined {member.joined}
                </div>
                <div className="flex items-center gap-2">
                  <Fingerprint className="h-3 w-3 text-emerald-400" />
                  {member.presentToday ? `Present ${member.checkInTime} · ${member.method}` : "Not checked-in today"}
                </div>
                <div className="flex items-center gap-2">
                  <CreditCard className="h-3 w-3 text-rose-400" />
                  Fee {formatMoney(member.fee)}/mo · {member.plan}
                </div>
              </div>
            </div>
            <div className="flex items-center justify-between border-t border-white/10 pt-2">
              <span className="font-mono text-[9px] uppercase tracking-widest text-slate-500">
                #Tap to flip back
              </span>
              {canDelete && (
                <span
                  role="button"
                  tabIndex={0}
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete(member.id);
                  }}
                  onKeyDown={(e) => e.key === "Enter" && onDelete(member.id)}
                  className="rounded-lg p-1.5 text-slate-500 transition hover:bg-rose-500/15 hover:text-rose-400"
                  title="Delete member"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </span>
              )}
            </div>
          </div>
        </motion.div>
      </motion.button>
    </motion.div>
  );
}

/* ───────────────────────── Add Member Modal (slide-up + confetti on save) ───────────────────────── */

function AddMemberModal({
  open,
  onClose,
  onAdd,
}: {
  open: boolean;
  onClose: () => void;
  onAdd: (m: Omit<Member, "id">) => void;
}) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [plan, setPlan] = useState<PlanName>("Standard");
  const [status, setStatus] = useState<PaymentStatus>("Paid");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !email.trim()) return;
    onAdd({
      name: name.trim(),
      phone: phone.trim(),
      email: email.trim(),
      plan,
      fee: PLAN_FEES[plan],
      status,
      absentDays: 0,
      presentToday: false,
      checkInTime: null,
      method: null,
      joined: new Date().toISOString().slice(0, 10),
    });
    setName("");
    setPhone("");
    setEmail("");
    setPlan("Standard");
    setStatus("Paid");
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/80 p-4 backdrop-blur-md sm:items-center"
          onClick={onClose}
        >
          <motion.div
            initial={{ y: 120, opacity: 0, scale: 0.96 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 120, opacity: 0, scale: 0.96 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            onClick={(e) => e.stopPropagation()}
            className="glass-panel w-full max-w-lg space-y-4 rounded-3xl border-white/15 p-6 shadow-2xl"
            role="dialog"
            aria-modal="true"
            aria-label="Register new gym member"
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="flex items-center gap-2 text-base font-bold text-white">
                <UserPlus className="h-5 w-5 text-emerald-400" />
                Register New Gym Member
              </h3>
              <button onClick={onClose} className="rounded-lg p-1 text-slate-400 transition hover:bg-slate-800 hover:text-white" aria-label="Close">
                <X className="h-5 w-5" />
              </button>
            </div>
            <form onSubmit={submit} className="space-y-4 text-xs">
              <div>
                <label className="mb-1 block font-medium text-slate-400">Full Name</label>
                <input
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="glass-input w-full rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none"
                  placeholder="e.g. Rayan Butt"
                />
              </div>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block font-medium text-slate-400">Phone Number</label>
                  <input
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="glass-input w-full rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none"
                    placeholder="+1 555-0900"
                  />
                </div>
                <div>
                  <label className="mb-1 block font-medium text-slate-400">Email Address</label>
                  <input
                    required
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="glass-input w-full rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none"
                    placeholder="rayan@pulse.io"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block font-medium text-slate-400">Membership Plan</label>
                  <select
                    value={plan}
                    onChange={(e) => setPlan(e.target.value as PlanName)}
                    className="glass-input w-full rounded-xl px-3.5 py-2.5 text-white focus:outline-none"
                  >
                    <option value="Standard">Standard ({formatMoney(PLAN_FEES.Standard)}/mo)</option>
                    <option value="Cardio Pro">Cardio Pro ({formatMoney(PLAN_FEES["Cardio Pro"])}/mo)</option>
                    <option value="Platinum VIP">Platinum VIP ({formatMoney(PLAN_FEES["Platinum VIP"])}/mo)</option>
                  </select>
                </div>
                <div>
                  <label className="mb-1 block font-medium text-slate-400">Payment Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as PaymentStatus)}
                    className="glass-input w-full rounded-xl px-3.5 py-2.5 text-white focus:outline-none"
                  >
                    <option value="Paid">Paid (Current)</option>
                    <option value="Pending">Pending Overdue</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end gap-3 border-t border-white/10 pt-3">
                <RippleButton variant="ghost" type="button" onClick={onClose}>
                  Cancel
                </RippleButton>
                <RippleButton variant="success" type="submit">
                  Save &amp; Enroll
                </RippleButton>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
