"use client";

import { useRef, useState, type ButtonHTMLAttributes } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface RippleButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "success" | "danger" | "warning" | "ghost" | "outline";
  size?: "sm" | "md" | "lg";
  children: React.ReactNode;
}

const VARIANTS: Record<NonNullable<RippleButtonProps["variant"]>, string> = {
  primary:
    "bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 text-white shadow-lg shadow-blue-600/25 hover:brightness-110",
  success:
    "bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-lg shadow-emerald-500/20 font-bold",
  danger:
    "bg-rose-500/90 hover:bg-rose-500 text-white shadow-lg shadow-rose-500/20",
  warning:
    "bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/20 font-bold",
  ghost:
    "bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 border border-white/10",
  outline:
    "bg-transparent hover:bg-slate-800/60 text-slate-300 border border-white/15",
};

const SIZES: Record<NonNullable<RippleButtonProps["size"]>, string> = {
  sm: "px-3 py-1.5 text-[11px]",
  md: "px-4 py-2.5 text-xs",
  lg: "px-7 py-3.5 text-xs",
};

/** Button with press scale 0.95 + material ripple ink on click. */
export function RippleButton({
  variant = "primary",
  size = "md",
  className,
  children,
  onClick,
  ...props
}: RippleButtonProps) {
  const ref = useRef<HTMLButtonElement>(null);
  const [ripples, setRipples] = useState<
    { id: number; x: number; y: number; size: number }[]
  >([]);

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    const btn = ref.current;
    if (btn) {
      const rect = btn.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      const ripple = {
        id: Date.now() + Math.random(),
        x: e.clientX - rect.left - size / 2,
        y: e.clientY - rect.top - size / 2,
        size,
      };
      setRipples((r) => [...r, ripple]);
      window.setTimeout(
        () => setRipples((r) => r.filter((x) => x.id !== ripple.id)),
        700,
      );
    }
    onClick?.(e);
  };

  return (
    <motion.button
      ref={ref}
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.95 }}
      transition={{ type: "spring", stiffness: 400, damping: 20 }}
      className={cn(
        "relative overflow-hidden rounded-xl font-semibold tracking-wide transition-all duration-200 flex items-center justify-center gap-2 select-none",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/60",
        VARIANTS[variant],
        SIZES[size],
        className,
      )}
      onClick={handleClick}
      {...props}
    >
      {ripples.map((r) => (
        <span
          key={r.id}
          className="ripple-ink"
          style={{
            left: r.x,
            top: r.y,
            width: r.size,
            height: r.size,
          }}
        />
      ))}
      {children}
    </motion.button>
  );
}
