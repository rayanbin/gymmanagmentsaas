"use client";

import { useMemo, useState, useEffect } from "react";
import { motion } from "framer-motion";
import {
  Users,
  DollarSign,
  AlertCircle,
  Wallet,
  TrendingUp,
  ArrowUpRight,
  Clock,
  UserX,
  Send,
  MessageSquare,
  Gauge,
  Check,
  Scan,
  UserPlus,
  Activity,
  Flame,
} from "lucide-react";
import { useGymStore } from "@/lib/gym/store";
import { RBAC, TOTAL_INCOME_MTD } from "@/lib/gym/types";
import { REVENUE_TREND } from "@/lib/gym/data";
import { GlassCard, staggerContainer, fadeSlideItem } from "./glass-card";
import { CountUp } from "./count-up";
import { RippleButton } from "./ripple-button";
import { formatMoney, initialsOf } from "@/lib/gym/data";
import { cn } from "@/lib/utils";

interface StatCardDef {
  id: string;
  label: string;
  value: number;
  prefix: string;
  color: string;
  bg: string;
  border: string;
  glow: string;
  icon: React.ElementType;
  sub: React.ReactNode;
}

export function DashboardView({ onNavigate }: { onNavigate: (tab: "attendance" | "members" | "expenses") => void }) {
  const members = useGymStore((s) => s.members);
  const expenses = useGymStore((s) => s.expenses);
  const role = useGymStore((s) => s.role);
  const rbac = RBAC[role];

  const totalExpenses = useMemo(
    () => expenses.reduce((s, e) => s + e.amount, 0),
    [expenses],
  );
  const netProfit = TOTAL_INCOME_MTD - totalExpenses;

  const absentees = useMemo(
    () =>
      members
        .filter((m) => m.absentDays > 0 || (!m.presentToday && m.absentDays >= 1))
        .sort((a, b) => b.absentDays - a.absentDays),
    [members],
  );
  const criticalCount = absentees.filter((m) => m.absentDays >= 3).length;

  const presentCount = members.filter((m) => m.presentToday).length;
  const todayRevenue = REVENUE_TREND[REVENUE_TREND.length - 1].revenue;
  const pendingDues = members
    .filter((m) => m.status === "Pending")
    .reduce((s, m) => s + m.fee, 0);

  const stats: StatCardDef[] = [
    {
      id: "members",
      label: "Total Members",
      value: 248,
      prefix: "",
      color: "text-blue-400",
      bg: "bg-blue-500/15",
      border: "border-blue-500/30",
      glow: "rgba(59,130,246,0.3)",
      icon: Users,
      sub: (
        <>
          <TrendingUp className="h-3.5 w-3.5" /> +12% this month
          <span className="ml-1 font-normal text-slate-500">• 92% active</span>
        </>
      ),
    },
    {
      id: "revenue",
      label: "Today's Revenue",
      value: todayRevenue,
      prefix: "$",
      color: "text-emerald-400",
      bg: "bg-emerald-500/15",
      border: "border-emerald-500/30",
      glow: "rgba(16,185,129,0.3)",
      icon: DollarSign,
      sub: (
        <>
          <ArrowUpRight className="h-3.5 w-3.5" /> +8.4% vs yesterday
          <span className="ml-1 font-normal text-slate-500">• 12 renewals</span>
        </>
      ),
    },
    {
      id: "dues",
      label: "Pending Dues",
      value: pendingDues,
      prefix: "$",
      color: "text-rose-400",
      bg: "bg-rose-500/15",
      border: "border-rose-500/30",
      glow: "rgba(239,68,68,0.3)",
      icon: AlertCircle,
      sub: (
        <>
          <Clock className="h-3.5 w-3.5" />
          {members.filter((m) => m.status === "Pending").length} overdue accounts
          <span className="ml-1 font-normal text-slate-500">• Follow-up needed</span>
        </>
      ),
    },
    {
      id: "profit",
      label: "Net Profit (MTD)",
      value: netProfit,
      prefix: "$",
      color: netProfit >= 0 ? "text-emerald-400" : "text-rose-400",
      bg: "bg-cyan-500/15",
      border: "border-cyan-500/30",
      glow: "rgba(6,182,212,0.3)",
      icon: Wallet,
      sub: (
        <>
          Income <strong className="text-emerald-400">{formatMoney(TOTAL_INCOME_MTD)}</strong>
          {" "}· Exp <strong className="text-rose-400">{formatMoney(totalExpenses)}</strong>
        </>
      ),
    },
  ];

  return (
    <motion.div
      variants={staggerContainer}
      initial="hidden"
      animate="show"
      className="space-y-6"
    >
      {/* Greeting & quick actions */}
      <motion.div
        variants={fadeSlideItem}
        className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between"
      >
        <div>
          <h1 className="flex flex-wrap items-center gap-3 text-2xl font-black tracking-tight text-white">
            Executive Analytics &amp; Biometrics
            <span className="rounded-full border border-blue-500/20 bg-blue-500/10 px-3 py-1 text-xs font-medium text-blue-400">
              Live Sync
            </span>
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Real-time attendance stream, risk watchlist, and automated P&amp;L ledger.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          {rbac.markAttendance && (
            <RippleButton onClick={() => onNavigate("attendance")}>
              <Scan className="h-4 w-4" />
              Launch Scanner Terminal
            </RippleButton>
          )}
          <RippleButton variant="ghost" onClick={() => onNavigate("members")}>
            <UserPlus className="h-4 w-4 text-emerald-400" />
            Add Member
          </RippleButton>
        </div>
      </motion.div>

      {/* 4 stat cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s, i) => (
          <GlassCard
            key={s.id}
            glowColor={s.glow}
            variants={fadeSlideItem}
            className="group overflow-hidden p-5"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  {s.label}
                </p>
                <h3 className={cn("mt-1 font-sans text-3xl font-black", s.color)}>
                  <CountUp end={s.value} prefix={s.prefix} />
                </h3>
              </div>
              <div
                className={cn(
                  "rounded-2xl border p-3 transition-transform duration-300 group-hover:scale-110",
                  s.bg,
                  s.color,
                  s.border,
                )}
              >
                <s.icon className="h-5 w-5" />
              </div>
            </div>
            <div className="mt-4 flex items-center gap-1 text-xs font-medium">
              {s.sub}
            </div>
            <div
              className={cn(
                "pointer-events-none absolute -bottom-6 -right-6 h-24 w-24 rounded-full blur-xl",
                s.bg,
              )}
            />
            {/* corner index for stagger debugging aesthetics */}
            <span className="absolute right-3 top-3 hidden font-mono text-[9px] text-slate-600">
              0{i + 1}
            </span>
          </GlassCard>
        ))}
      </div>

      {/* Revenue chart */}
      <GlassCard variants={fadeSlideItem} hoverLift={false} className="p-6">
        <div className="flex flex-col gap-4 border-b border-white/10 pb-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="flex items-center gap-2 text-base font-bold text-white">
              <Activity className="h-4 w-4 text-blue-400" />
              Revenue Velocity vs. Daily Footfall Correlation
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Dual-metric trajectory over the last 7 operating days with live scanner sync.
            </p>
          </div>
          <div className="flex items-center gap-4 font-mono text-xs">
            <div className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-full bg-blue-500 shadow-sm shadow-blue-500" />
              <span className="text-slate-300">Revenue ($)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400" />
              <span className="text-slate-300">Biometric Check-ins</span>
            </div>
          </div>
        </div>
        <RevenueChart />
      </GlassCard>

      {/* Absentee widget + capacity gauge */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <AbsenteeWidget
          absentees={absentees}
          criticalCount={criticalCount}
          onNavigate={onNavigate}
        />
        <CapacityGauge presentCount={presentCount} />
      </div>
    </motion.div>
  );
}

/* ───────────────────────── Revenue Chart (animated SVG line draw) ───────────────────────── */

function RevenueChart() {
  const [hover, setHover] = useState<number | null>(null);
  const W = 700;
  const H = 200;

  const revenues = REVENUE_TREND.map((d) => d.revenue);
  const checkins = REVENUE_TREND.map((d) => d.checkins);
  const maxRev = Math.max(...revenues) * 1.15;
  const maxChk = Math.max(...checkins) * 1.15;

  const toPoints = (vals: number[], max: number) =>
    vals.map((v, i) => ({
      x: (i / (vals.length - 1)) * W,
      y: H - (v / max) * (H - 24) - 12,
    }));

  const revPts = toPoints(revenues, maxRev);
  const chkPts = toPoints(checkins, maxChk);

  const smoothPath = (pts: { x: number; y: number }[]) => {
    // Catmull-Rom → cubic bezier smoothing
    let d = `M ${pts[0].x} ${pts[0].y}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[Math.max(0, i - 1)];
      const p1 = pts[i];
      const p2 = pts[i + 1];
      const p3 = pts[Math.min(pts.length - 1, i + 2)];
      const c1x = p1.x + (p2.x - p0.x) / 6;
      const c1y = p1.y + (p2.y - p0.y) / 6;
      const c2x = p2.x - (p3.x - p1.x) / 6;
      const c2y = p2.y - (p3.y - p1.y) / 6;
      d += ` C ${c1x} ${c1y}, ${c2x} ${c2y}, ${p2.x} ${p2.y}`;
    }
    return d;
  };

  const revPath = smoothPath(revPts);
  const chkPath = smoothPath(chkPts);
  const revArea = `${revPath} L ${W} ${H} L 0 ${H} Z`;
  const chkArea = `${chkPath} L ${W} ${H} L 0 ${H} Z`;

  const days = REVENUE_TREND.map((d) => d.day);

  return (
    <div className="mt-4">
      <div className="relative h-56 w-full">
        <svg className="h-full w-full overflow-visible" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
          <defs>
            <linearGradient id="blueGlow" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
            </linearGradient>
            <linearGradient id="emeraldGlow" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="#10b981" stopOpacity="0.28" />
              <stop offset="100%" stopColor="#10b981" stopOpacity="0" />
            </linearGradient>
          </defs>
          {[40, 90, 140].map((y) => (
            <line key={y} x1="0" x2={W} y1={y} y2={y} stroke="rgba(255,255,255,0.05)" strokeDasharray="4" />
          ))}
          <motion.path
            d={revArea}
            fill="url(#blueGlow)"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.1, duration: 0.9 }}
          />
          <motion.path
            d={chkArea}
            fill="url(#emeraldGlow)"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.3, duration: 0.9 }}
          />
          <motion.path
            d={revPath}
            fill="none"
            stroke="#3b82f6"
            strokeWidth="3"
            strokeLinecap="round"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1.6, ease: "easeInOut", delay: 0.3 }}
          />
          <motion.path
            d={chkPath}
            fill="none"
            stroke="#10b981"
            strokeWidth="2.5"
            strokeLinecap="round"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1.6, ease: "easeInOut", delay: 0.55 }}
          />
          {revPts.map((p, i) => (
            <motion.circle
              key={`rev-${i}`}
              cx={p.x}
              cy={p.y}
              r={hover === i ? 7 : 5}
              fill="#3b82f6"
              stroke={i === revPts.length - 1 ? "#ffffff" : "#0a0f1d"}
              strokeWidth="2"
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 1.2 + i * 0.08, type: "spring", stiffness: 300 }}
              className="cursor-pointer"
              onMouseEnter={() => setHover(i)}
              onMouseLeave={() => setHover(null)}
            />
          ))}
          {chkPts.map((p, i) => (
            <motion.circle
              key={`chk-${i}`}
              cx={p.x}
              cy={p.y}
              r={hover === i ? 6 : 4.5}
              fill="#10b981"
              stroke={i === chkPts.length - 1 ? "#ffffff" : "#0a0f1d"}
              strokeWidth="2"
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 1.4 + i * 0.08, type: "spring", stiffness: 300 }}
              className="cursor-pointer"
              onMouseEnter={() => setHover(i)}
              onMouseLeave={() => setHover(null)}
            />
          ))}
        </svg>
        {/* tooltip */}
        {hover !== null && (
          <motion.div
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-panel pointer-events-none absolute z-10 rounded-xl px-3 py-2 font-mono text-[10px] shadow-xl"
            style={{
              left: `${(hover / (REVENUE_TREND.length - 1)) * 100}%`,
              top: 4,
              transform: "translateX(-50%)",
            }}
          >
            <div className="font-bold text-blue-300">
              Rev {formatMoney(REVENUE_TREND[hover].revenue)}
            </div>
            <div className="text-emerald-300">
              Check-ins {REVENUE_TREND[hover].checkins}
            </div>
          </motion.div>
        )}
      </div>
      <div className="mt-2 flex justify-between px-1 font-mono text-[11px] text-slate-500">
        {days.map((d, i) => (
          <span key={d} className={i === days.length - 1 ? "font-bold text-blue-400" : ""}>
            {i === days.length - 1 ? "Today (Sun)" : `${d}`}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ───────────────────────── Absentee Watchlist (auto-scroll + pulsing dots) ───────────────────────── */

function AbsenteeWidget({
  absentees,
  criticalCount,
  onNavigate,
}: {
  absentees: { id: string; name: string; plan: string; status: string; fee: number; absentDays: number }[];
  criticalCount: number;
  onNavigate: (t: "attendance" | "members" | "expenses") => void;
}) {
  const [nudged, setNudged] = useState<string[]>([]);

  const nudge = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setNudged((n) => [...n, id]);
    window.setTimeout(() => setNudged((n) => n.filter((x) => x !== id)), 2200);
  };

  return (
    <GlassCard variants={fadeSlideItem} hoverLift={false} className="flex flex-col justify-between p-5 lg:col-span-7">
      <div>
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl border border-rose-500/30 bg-rose-500/15 text-rose-400">
              <UserX className="h-4 w-4" />
            </div>
            <div>
              <h2 className="flex items-center gap-2 text-sm font-bold text-white">
                Consecutive Absentee Tracker
                <span className="rounded-full border border-rose-500/30 bg-rose-500/20 px-2 py-0.5 text-[10px] font-bold text-rose-400">
                  High Risk
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Automated churn prediction based on zero biometric logs
              </p>
            </div>
          </div>
          {criticalCount > 0 && (
            <motion.span
              animate={{ opacity: [1, 0.55, 1] }}
              transition={{ repeat: Infinity, duration: 1.8 }}
              className="rounded-lg border border-rose-800/50 bg-rose-950/50 px-2.5 py-1 font-mono text-xs font-bold text-rose-400"
            >
              {criticalCount} Critical At-Risk
            </motion.span>
          )}
        </div>

        {/* scrolling list — duplicated for seamless loop when overflowing */}
        <div className="scrollbar-thin mt-4 max-h-72 space-y-2.5 overflow-y-auto pr-1">
          {absentees.length === 0 && (
            <div className="flex items-center justify-center rounded-xl border border-emerald-500/20 bg-emerald-500/10 p-6 text-xs text-emerald-300">
              <Check className="mr-2 h-4 w-4" /> Zero absentee risk — full roster active this week.
            </div>
          )}
          {absentees.map((m) => {
            const critical = m.absentDays >= 3;
            const moderate = m.absentDays >= 2;
            return (
              <motion.button
                key={m.id}
                layout
                initial={{ opacity: 0, x: -24 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 24 }}
                transition={{ type: "spring", stiffness: 260, damping: 26 }}
                onClick={() => onNavigate("members")}
                className={cn(
                  "group flex w-full items-center justify-between rounded-xl border p-3 text-left transition",
                  critical
                    ? "border-rose-500/30 bg-rose-950/20 hover:border-rose-500/60"
                    : moderate
                      ? "border-rose-500/20 bg-rose-950/10 hover:border-rose-500/40"
                      : "border-rose-500/15 bg-slate-900/60 hover:border-rose-500/30",
                )}
              >
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div
                      className={cn(
                        "flex h-9 w-9 items-center justify-center rounded-xl border text-xs font-bold",
                        critical
                          ? "border-rose-500/40 bg-slate-800 text-rose-300"
                          : "border-slate-700 bg-slate-800 text-slate-300",
                      )}
                    >
                      {initialsOf(m.name)}
                    </div>
                    {/* pulsing red dot */}
                    <span
                      className={cn(
                        "absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-navy-900",
                        critical ? "animate-ping bg-rose-500" : moderate ? "bg-rose-500" : "bg-amber-500",
                      )}
                    />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 text-xs font-bold text-white">
                      {m.name}
                      <span className="font-mono text-[10px] font-normal text-slate-400">#{m.id}</span>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      {m.plan} • {m.status === "Pending" ? `Overdue ${formatMoney(m.fee)}` : "Paid"} • Last active: {m.absentDays}d ago
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className={cn(
                      "rounded-lg border px-2.5 py-1 text-xs font-bold",
                      critical
                        ? "border-rose-500/30 bg-rose-500/20 text-rose-400"
                        : "border-amber-500/30 bg-amber-500/15 text-amber-400",
                    )}
                  >
                    Absent {m.absentDays}d
                  </span>
                  <span
                    role="button"
                    tabIndex={0}
                    onClick={(e) => nudge(m.id, e)}
                    onKeyDown={(e) => e.key === "Enter" && nudge(m.id, e as unknown as React.MouseEvent)}
                    className="flex items-center gap-1 rounded-lg bg-blue-600/80 px-2.5 py-1 text-xs font-semibold text-white shadow-sm transition hover:bg-blue-500 active:scale-95"
                  >
                    <Send className="h-3 w-3" /> {nudged.includes(m.id) ? "Sent ✓" : "Nudge"}
                  </span>
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between border-t border-white/10 pt-3 text-xs">
        <span className="text-slate-400">
          Total Retention Risk:{" "}
          <strong className="text-rose-400">
            {absentees.length === 0 ? "0" : Math.min(48, absentees.length * 2.1 + 8).toFixed(1)}%
          </strong>
        </span>
        <button
          onClick={() => onNavigate("members")}
          className="flex items-center gap-1.5 font-semibold text-blue-400 transition hover:text-blue-300"
        >
          <MessageSquare className="h-3.5 w-3.5" /> Send Bulk Automated WhatsApp Nudges
        </button>
      </div>
    </GlassCard>
  );
}

/* ───────────────────────── Floor Capacity Gauge ───────────────────────── */

function CapacityGauge({ presentCount }: { presentCount: number }) {
  const [occupied, setOccupied] = useState(48);
  useEffect(() => {
    const t = window.setInterval(() => {
      setOccupied((o) => Math.max(36, Math.min(72, o + (Math.random() > 0.5 ? 1 : -1))));
    }, 3500);
    return () => window.clearInterval(t);
  }, []);

  const capacity = Math.min(1, occupied / 120);
  const dash = 264;
  const offset = dash * (1 - capacity);

  return (
    <GlassCard variants={fadeSlideItem} hoverLift={false} className="flex flex-col justify-between p-5 lg:col-span-5">
      <div>
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div>
            <h2 className="flex items-center gap-2 text-sm font-bold text-white">
              <Gauge className="h-4 w-4 text-emerald-400" />
              Gym Floor Capacity Sensor
            </h2>
            <p className="text-xs text-slate-400">Entrance turnstile minus exit optical gate count</p>
          </div>
          <span className="rounded-lg border border-emerald-500/30 bg-emerald-500/15 px-2.5 py-1 font-mono text-xs font-bold text-emerald-400">
            Normal Zone
          </span>
        </div>

        <div className="my-6 flex items-center justify-center">
          <div className="relative flex h-40 w-40 items-center justify-center">
            <svg className="h-full w-full -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="42" fill="transparent" stroke="rgba(255,255,255,0.08)" strokeWidth="8" />
              <motion.circle
                cx="50"
                cy="50"
                r="42"
                fill="transparent"
                stroke="url(#capGrad)"
                strokeDasharray={dash}
                strokeLinecap="round"
                strokeWidth="8"
                initial={{ strokeDashoffset: dash }}
                animate={{ strokeDashoffset: offset }}
                transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1], delay: 0.4 }}
              />
              <defs>
                <linearGradient id="capGrad" x1="0%" x2="100%" y1="0%" y2="100%">
                  <stop offset="0%" stopColor="#10b981" />
                  <stop offset="70%" stopColor="#06b6d4" />
                  <stop offset="100%" stopColor="#3b82f6" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute text-center">
              <CountUp end={occupied} className="text-3xl font-black tracking-tight text-white" />
              <span className="block font-mono text-xs text-slate-400">/ 120 Max</span>
              <span className="mt-0.5 block text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                {Math.round(capacity * 100)}% Cap
              </span>
            </div>
          </div>
        </div>

        <div className="space-y-2 text-xs">
          {[
            { label: "Cardio Deck:", val: "18 athletes (60%)" },
            { label: "Free Weights & Power Racks:", val: "22 athletes (55%)" },
            { label: "CrossFit / Functional Turf:", val: "8 athletes (20%)" },
          ].map((row) => (
            <div key={row.label} className="flex justify-between text-slate-400">
              <span>{row.label}</span>
              <span className="font-mono font-medium text-white">{row.val}</span>
            </div>
          ))}
          <div className="flex justify-between border-t border-white/5 pt-2 text-slate-400">
            <span className="flex items-center gap-1.5">
              <Flame className="h-3.5 w-3.5 text-orange-400" /> Checked-in today:
            </span>
            <span className="font-mono font-medium text-emerald-400">{presentCount} members</span>
          </div>
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between border-t border-white/10 pt-3 text-[11px] text-slate-400">
        <span className="flex items-center gap-1">
          <Check className="h-3.5 w-3.5 text-emerald-400" /> Air quality: 99.2% Good
        </span>
        <span className="font-mono text-blue-400">Optimal Training Flow</span>
      </div>
    </GlassCard>
  );
}
