"use client";

import { motion, AnimatePresence } from "framer-motion";
import {
  ShieldCheck,
  ChevronDown,
  Sparkles,
  Crown,
  Shield,
  ClipboardList,
  Menu,
  Check,
  Zap,
} from "lucide-react";
import { useState } from "react";
import { ROLE_PROFILES, RBAC, type Role } from "@/lib/gym/types";
import { useGymStore } from "@/lib/gym/store";
import { cn } from "@/lib/utils";

const ROLE_ICONS = { crown: Crown, shield: Shield, clipboard: ClipboardList } as const;

const ROLE_DESC: Record<Role, string> = {
  owner: "Superadmin: Can mutate membership rates, manage expenses, and configure hardware.",
  manager: "Manager: Can view Dashboard, mark attendance, and view expenses. Fee edits locked.",
  staff: "Staff: Strictly Add/View Members. Attendance marking and expense controls locked.",
};

interface TopbarProps {
  onOpenMobileNav: () => void;
}

export function Topbar({ onOpenMobileNav }: TopbarProps) {
  const role = useGymStore((s) => s.role);
  const setRole = useGymStore((s) => s.setRole);
  const setBooting = useGymStore((s) => s.setBooting);
  const [open, setOpen] = useState(false);

  const profile = ROLE_PROFILES[role];
  const ProfileIcon = ROLE_ICONS[profile.icon as keyof typeof ROLE_ICONS];

  const pickRole = (r: Role) => {
    setRole(r);
    setOpen(false);
    // event-driven skeleton shimmer so every view re-loads with feedback
    setBooting(true);
    window.setTimeout(() => setBooting(false), 750);
  };

  return (
    <motion.header
      initial={{ y: -70, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      className="glass-panel sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-white/10 px-4 py-3 sm:px-6"
    >
      {/* Brand */}
      <div className="flex min-w-0 items-center gap-3.5">
        <button
          onClick={onOpenMobileNav}
          className="rounded-lg border border-white/10 bg-slate-800/80 p-2 text-slate-300 lg:hidden"
          aria-label="Open navigation"
        >
          <Menu className="h-4 w-4" />
        </button>
        <div className="relative hidden cursor-pointer group sm:block">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-500 to-cyan-400 shadow-lg shadow-blue-500/25 transition-transform duration-300 group-hover:scale-105">
            <Zap className="h-5 w-5 fill-white text-white" />
          </div>
          <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-navy-900 bg-emerald-400" />
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="truncate bg-gradient-to-r from-white via-slate-100 to-blue-300 bg-clip-text text-lg font-extrabold tracking-tight text-transparent">
              PulseForge
            </span>
            <span className="hidden rounded-full border border-blue-500/30 bg-blue-500/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-blue-400 sm:inline">
              v2.5 SaaS
            </span>
          </div>
          <p className="hidden text-[11px] text-slate-400 md:block">
            IronPulse Elite Gym Operations
          </p>
        </div>
      </div>

      {/* RBAC role simulator */}
      <div className="relative hidden items-center gap-3 rounded-2xl border border-white/10 bg-slate-900/80 px-4 py-1.5 shadow-inner backdrop-blur-md md:flex">
        <div className="flex items-center gap-2 text-xs font-medium text-slate-300">
          <ShieldCheck className="h-4 w-4 text-emerald-400" />
          <span>Simulated RBAC Role:</span>
        </div>
        <button
          onClick={() => setOpen((o) => !o)}
          className={cn(
            "flex items-center gap-2 rounded-lg border border-blue-500/40 bg-navy-950 px-3 py-1.5 text-xs font-semibold text-blue-400 shadow-sm transition hover:border-blue-400/60 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 active:scale-95",
          )}
          aria-haspopup="listbox"
          aria-expanded={open}
        >
          <ProfileIcon className="h-3.5 w-3.5" />
          {profile.title} ({profile.tagline})
          <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", open && "rotate-180")} />
        </button>
        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, y: -8, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.97 }}
              transition={{ duration: 0.18 }}
              className="glass-panel absolute left-0 top-full z-50 mt-2 w-80 rounded-2xl p-2 shadow-2xl"
              role="listbox"
            >
              {Object.values(ROLE_PROFILES).map((p) => {
                const Icon = ROLE_ICONS[p.icon as keyof typeof ROLE_ICONS];
                const active = p.id === role;
                return (
                  <button
                    key={p.id}
                    onClick={() => pickRole(p.id)}
                    className={cn(
                      "flex w-full items-start gap-3 rounded-xl p-3 text-left transition",
                      active ? "bg-blue-500/15" : "hover:bg-slate-800/70",
                    )}
                    role="option"
                    aria-selected={active}
                  >
                    <span
                      className={cn(
                        "mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-tr",
                        p.gradient,
                      )}
                    >
                      <Icon className="h-4 w-4 text-white" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-2 text-xs font-bold text-white">
                        {p.title}
                        <span className={cn("rounded-full border px-1.5 py-px text-[9px] font-bold uppercase", p.badgeClass)}>
                          {RBAC[p.id].markAttendance ? "Attendance ✓" : "Attendance ✗"}
                        </span>
                      </span>
                      <span className="mt-0.5 block text-[11px] leading-snug text-slate-400">
                        {ROLE_DESC[p.id]}
                      </span>
                    </span>
                    {active && <Check className="mt-1 h-4 w-4 shrink-0 text-blue-400" />}
                  </button>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>
        <div className="hidden max-w-xs truncate border-l border-slate-700/80 pl-3 text-[11px] text-slate-400 lg:block">
          {ROLE_DESC[role]}
        </div>
      </div>

      {/* Right controls */}
      <div className="flex items-center gap-3">
        {/* skeleton shimmer demo toggle */}
        <button
          onClick={() => setBooting(!booting)}
          className="hidden items-center gap-1.5 rounded-xl border border-white/10 bg-slate-800/80 px-2.5 py-1.5 text-[11px] font-medium text-slate-300 transition hover:bg-slate-700/80 sm:flex"
          title="Inspect skeleton load state"
        >
          <Sparkles className="h-3.5 w-3.5 text-blue-400" />
          <span className="hidden lg:inline">Demo Shimmer</span>
        </button>

        {/* hardware status */}
        <div className="hidden items-center gap-2 rounded-xl border border-white/10 bg-slate-800/60 px-3 py-1 text-xs text-slate-300 sm:flex">
          <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-400" />
          <span className="font-mono text-[11px]">Gate Bio-7: Online</span>
        </div>

        {/* avatar with breathing animation */}
        <div className="flex items-center gap-3 border-l border-slate-800 pl-3">
          <motion.div key={role} initial={{ scale: 0.8 }} animate={{ scale: 1 }} className="relative">
            <div className="breathing flex h-9 w-9 items-center justify-center rounded-xl border border-blue-500/40 bg-gradient-to-tr from-slate-700 to-slate-800 text-xs font-bold text-white">
              {profile.persona.split(" ").map((n) => n[0]).join("")}
            </div>
            <span className="absolute -bottom-1 -right-1 h-3 w-3 rounded-full border-2 border-navy-900 bg-blue-500" />
          </motion.div>
          <div className="hidden text-left text-xs xl:block">
            <div className="font-bold tracking-wide text-white">
              {profile.persona}
            </div>
            <div className="text-[10px] font-medium text-blue-400">
              {profile.subtitle}
            </div>
          </div>
        </div>
      </div>

      {/* mobile role switcher chip */}
      <div className="relative md:hidden">
        <button
          onClick={() => setOpen((o) => !o)}
          className={cn(
            "flex items-center gap-1.5 rounded-xl border px-2.5 py-1.5 text-[10px] font-bold uppercase tracking-wider",
            profile.badgeClass,
          )}
          aria-expanded={open}
        >
          <ProfileIcon className="h-3.5 w-3.5" />
          {profile.title}
          <ChevronDown className={cn("h-3 w-3 transition-transform", open && "rotate-180")} />
        </button>
        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, y: -8, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.97 }}
              transition={{ duration: 0.18 }}
              className="glass-panel absolute right-0 top-full z-50 mt-2 w-64 rounded-2xl p-2 shadow-2xl"
              role="listbox"
            >
              {Object.values(ROLE_PROFILES).map((p) => {
                const Icon = ROLE_ICONS[p.icon as keyof typeof ROLE_ICONS];
                const active = p.id === role;
                return (
                  <button
                    key={p.id}
                    onClick={() => pickRole(p.id)}
                    className={cn(
                      "flex w-full items-center gap-3 rounded-xl p-2.5 text-left transition",
                      active ? "bg-blue-500/15" : "hover:bg-slate-800/70",
                    )}
                    role="option"
                    aria-selected={active}
                  >
                    <span
                      className={cn(
                        "flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-gradient-to-tr",
                        p.gradient,
                      )}
                    >
                      <Icon className="h-3.5 w-3.5 text-white" />
                    </span>
                    <span className="min-w-0 flex-1 text-xs font-bold text-white">
                      {p.title}
                      <span className="block text-[10px] font-normal text-slate-400">
                        {p.subtitle}
                      </span>
                    </span>
                    {active && <Check className="h-4 w-4 shrink-0 text-blue-400" />}
                  </button>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.header>
  );
}
