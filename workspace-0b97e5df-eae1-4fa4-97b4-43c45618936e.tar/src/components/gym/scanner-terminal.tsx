"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Fingerprint, Scan, X, Check, QrCode, Radio } from "lucide-react";
import { useGymStore } from "@/lib/gym/store";
import { RippleButton } from "./ripple-button";
import { AuditStreamFooter, ScanAuditHeader } from "./attendance-view";
import { SCANNER_QUEUE } from "@/lib/gym/data";
import { burstConfetti } from "@/lib/gym/confetti";
import { initialsOf } from "@/lib/gym/data";
import { cn } from "@/lib/utils";

type ScanPhase = "idle" | "scanning" | "success" | "failure";

interface ScanOutcome {
  success: boolean;
  memberName?: string;
  memberId?: string;
  confidence?: number;
  plan?: string;
}

/* ───────────────────────── Real-time clock with smooth digit transitions ───────────────────────── */
function LiveClock() {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    // defer first paint value out of the effect body (async) to avoid cascading render
    const raf = requestAnimationFrame(() => setNow(new Date()));
    const t = window.setInterval(() => setNow(new Date()), 1000);
    return () => {
      cancelAnimationFrame(raf);
      window.clearInterval(t);
    };
  }, []);

  if (!now) {
    return (
      <span className="rounded-lg border border-blue-500/30 bg-blue-500/10 px-2.5 py-1 font-mono text-xs text-blue-400">
        --:--:--
      </span>
    );
  }

  const parts = now.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });
  const chars = parts.split("");

  return (
    <span className="flex items-center gap-px rounded-lg border border-blue-500/30 bg-blue-500/10 px-2.5 py-1 font-mono text-xs text-blue-400">
      {chars.map((c, i) => (
        <span key={`${i}-${c}`} className="relative inline-block overflow-hidden" style={{ width: c === " " ? "0.25em" : "auto" }}>
          <AnimatePresence mode="popLayout" initial={false}>
            <motion.span
              key={`${i}-${c}`}
              initial={{ y: 12, opacity: 0, filter: "blur(2px)" }}
              animate={{ y: 0, opacity: 1, filter: "blur(0px)" }}
              exit={{ y: -12, opacity: 0, filter: "blur(2px)" }}
              transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
              className="inline-block"
            >
              {c === " " ? "\u00A0" : c}
            </motion.span>
          </AnimatePresence>
        </span>
      ))}
    </span>
  );
}

/* ───────────────────────── Scanner Terminal (Flow B) ───────────────────────── */

export function ScannerTerminal() {
  const members = useGymStore((s) => s.members);
  const markPresent = useGymStore((s) => s.markPresent);
  const scanEvents = useGymStore((s) => s.scanEvents);
  const pushScanEvent = useGymStore((s) => s.pushScanEvent);

  const [phase, setPhase] = useState<ScanPhase>("idle");
  const [outcome, setOutcome] = useState<ScanOutcome | null>(null);
  const [mode, setMode] = useState<"qr" | "fingerprint">("qr");
  const queueIdx = useRef(0);
  const timers = useRef<number[]>([]);

  useEffect(() => () => timers.current.forEach((t) => window.clearTimeout(t)), []);

  const runScan = () => {
    if (phase === "scanning") return;

    // resolve the mock queue entry
    const targetId = SCANNER_QUEUE[queueIdx.current % SCANNER_QUEUE.length];
    queueIdx.current += 1;

    setOutcome(null);
    setPhase("scanning");

    const t1 = window.setTimeout(() => {
      const member = members.find((m) => m.id === targetId);
      if (member) {
        const time = markPresent([member.id], "Biometric");
        setOutcome({
          success: true,
          memberName: member.name,
          memberId: member.id,
          confidence: 97 + Math.random() * 2.9,
          plan: member.plan,
        });
        setPhase("success");
        pushScanEvent({
          id: `scan-${Date.now()}`,
          memberName: member.name,
          memberId: member.id,
          confidence: 97 + Math.random() * 2.9,
          plan: member.plan,
          time,
          success: true,
        });
        burstConfetti(0.42, 0.5);
      } else {
        setOutcome({ success: false, memberId: targetId });
        setPhase("failure");
        pushScanEvent({
          id: `scan-${Date.now()}`,
          memberName: "Unknown Subject",
          memberId: targetId,
          confidence: 12.4,
          plan: "—",
          time: new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true }),
          success: false,
        });
      }

      const t2 = window.setTimeout(() => {
        setPhase("idle");
        setOutcome(null);
      }, 2600);
      timers.current.push(t2);
    }, 1900);
    timers.current.push(t1);
  };

  const busy = phase === "scanning";

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      {/* ── Hardware terminal screen ── */}
      <div className="glass-panel relative flex min-h-[480px] flex-col items-center justify-center overflow-hidden rounded-3xl p-8 text-center lg:col-span-7">
        {/* cyber grid */}
        <div className="pointer-events-none absolute inset-0 opacity-10 [background-image:radial-gradient(#3b82f6_1px,transparent_1px)] [background-size:20px_20px]" />
        <div className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-blue-600/15 blur-[110px]" />

        {/* terminal info bar */}
        <div className="relative z-10 mb-6 flex w-full items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-emerald-400" />
            <span className="font-mono font-semibold uppercase tracking-wider">
              PulseGate-Biom9000 [Turnstile_01]
            </span>
          </div>
          <LiveClock />
        </div>

        {/* scanner ring */}
        <motion.button
          onClick={runScan}
          disabled={busy}
          whileHover={!busy ? { scale: 1.03 } : undefined}
          whileTap={!busy ? { scale: 0.97 } : undefined}
          className="group relative my-4 cursor-pointer outline-none disabled:cursor-wait"
          aria-label="Trigger biometric scan"
        >
          {/* pulsing aura rings */}
          <span className="pulse-glow pointer-events-none absolute -inset-6 rounded-full bg-blue-500/20" />
          <span
            className="pulse-glow pointer-events-none absolute -inset-12 rounded-full bg-cyan-500/10"
            style={{ animationDelay: "0.8s" }}
          />
          {/* rotating dashed ring */}
          <span className="spin-slow pointer-events-none absolute -inset-8 rounded-full border border-dashed border-blue-400/25" />

          {/* sensor frame */}
          <motion.div
            animate={
              phase === "failure"
                ? { x: [0, -9, 8, -6, 5, -3, 0] }
                : phase === "success"
                  ? { scale: [1, 1.06, 1] }
                  : {}
            }
            transition={{ duration: 0.55 }}
            className={cn(
              "relative flex h-44 w-44 flex-col items-center justify-center overflow-hidden rounded-3xl border-2 shadow-2xl transition-colors duration-300",
              phase === "success"
                ? "border-emerald-400 bg-emerald-950/60 shadow-emerald-500/30"
                : phase === "failure"
                  ? "border-rose-500 bg-rose-950/60 shadow-rose-500/30"
                  : "border-blue-500/50 bg-navy-950/90 shadow-blue-500/30 group-hover:border-blue-400",
            )}
          >
            {/* laser sweep line */}
            {busy && (
              <span className="laser-active absolute left-0 z-10 h-1.5 w-full bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_15px_#06b6d4]" />
            )}

            <AnimatePresence mode="wait">
              {phase === "success" ? (
                <motion.span
                  key="ok"
                  initial={{ scale: 0, rotate: -30 }}
                  animate={{ scale: 1, rotate: 0 }}
                  exit={{ scale: 0 }}
                  transition={{ type: "spring", stiffness: 380, damping: 20 }}
                  className="relative flex"
                >
                  <Check className="h-16 w-16 text-emerald-400" strokeWidth={3} />
                  <span className="burst-ring absolute inset-0 rounded-full border-4 border-emerald-400" />
                  <span
                    className="burst-ring absolute inset-0 rounded-full border-2 border-emerald-300"
                    style={{ animationDelay: "0.25s" }}
                  />
                </motion.span>
              ) : phase === "failure" ? (
                <motion.span
                  key="fail"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                  transition={{ type: "spring", stiffness: 380, damping: 20 }}
                  className="relative flex"
                >
                  <X className="h-16 w-16 text-rose-400" strokeWidth={3} />
                  <span className="burst-ring absolute inset-0 rounded-full border-4 border-rose-400" />
                </motion.span>
              ) : mode === "qr" ? (
                <motion.span
                  key="qr"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="flex"
                >
                  <QrCode className={cn("h-16 w-16 text-blue-400", busy && "animate-pulse")} />
                </motion.span>
              ) : (
                <motion.span
                  key="fp"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="flex"
                >
                  <Fingerprint className={cn("h-16 w-16 text-blue-400", busy && "animate-pulse")} />
                </motion.span>
              )}
            </AnimatePresence>

            <span className="mt-2 font-mono text-[10px] tracking-wider text-slate-400">
              {busy ? "SCANNING…" : phase === "success" ? "ACCESS GRANTED" : phase === "failure" ? "ACCESS DENIED" : "READY TO SCAN"}
            </span>
          </motion.div>
        </motion.button>

        {/* scan outcome banner with member slide-in */}
        <div className="relative z-10 mt-2 min-h-[92px] w-full max-w-md">
          <AnimatePresence mode="wait">
            {phase === "success" && outcome?.memberName ? (
              <motion.div
                key="success-banner"
                initial={{ opacity: 0, x: 80, scale: 0.95 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={{ opacity: 0, y: -14 }}
                transition={{ type: "spring", stiffness: 260, damping: 24 }}
                className="flex items-center gap-3 rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-3.5 text-left"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-emerald-500 to-cyan-500 text-xs font-black text-white">
                  {initialsOf(outcome.memberName)}
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-bold text-white">
                    Welcome, {outcome.memberName}
                    <span className="ml-1.5 font-mono text-[10px] text-slate-400">#{outcome.memberId}</span>
                  </div>
                  <div className="text-[11px] text-emerald-300">
                    {outcome.plan} · Turnstile released · Confidence {outcome.confidence?.toFixed(1)}%
                  </div>
                </div>
                <Check className="ml-auto h-5 w-5 shrink-0 text-emerald-400" />
              </motion.div>
            ) : phase === "failure" ? (
              <motion.div
                key="fail-banner"
                initial={{ opacity: 0, x: 60 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, y: -14 }}
                className="rounded-2xl border border-rose-500/40 bg-rose-500/10 p-3.5 text-xs text-rose-300"
              >
                <strong className="font-bold">Match Failed:</strong> Fingerprint/QR #{outcome?.memberId} is not
                registered in the biometrics vault. Membership intake required at front desk.
              </motion.div>
            ) : (
              <motion.div
                key="idle-banner"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex min-h-[56px] items-center justify-center rounded-2xl border border-white/10 bg-slate-900/80 p-3.5 text-xs font-medium text-slate-400"
              >
                {busy
                  ? "Reading optical/biometric signature — match against member registry…"
                  : mode === "qr"
                    ? "Hold member QR pass toward the optical sensor, or press the scan button to simulate."
                    : "Touch scanner glass or click the button to verify biometrics and trigger turnstile."}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* trigger buttons */}
        <div className="relative z-10 mt-4 flex flex-wrap items-center justify-center gap-3">
          <RippleButton
            size="lg"
            onClick={() => {
              setMode("qr");
              runScan();
            }}
            disabled={busy}
            className={cn(busy && "pointer-events-none opacity-60")}
          >
            {mode === "qr" && busy ? (
              <motion.span
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 0.9, ease: "linear" }}
                className="inline-flex"
              >
                <Radio className="h-4 w-4" />
              </motion.span>
            ) : (
              <Scan className="h-4 w-4" />
            )}
            {mode === "qr" && busy ? "Scanning QR…" : "Scan QR Code"}
          </RippleButton>
          <RippleButton
            size="lg"
            variant="ghost"
            onClick={() => {
              setMode("fingerprint");
              runScan();
            }}
            disabled={busy}
            className={cn(busy && "pointer-events-none opacity-60")}
          >
            {mode === "fingerprint" && busy ? (
              <motion.span
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 0.9, ease: "linear" }}
                className="inline-flex"
              >
                <Radio className="h-4 w-4" />
              </motion.span>
            ) : (
              <Fingerprint className="h-4 w-4 text-cyan-400" />
            )}
            {mode === "fingerprint" && busy ? "Verifying…" : "Fingerprint"}
          </RippleButton>
        </div>
      </div>

      {/* ── Audit stream ── */}
      <div className="glass-card flex flex-col justify-between rounded-3xl p-6 lg:col-span-5">
        <div>
          <ScanAuditHeader />
          <div className="scrollbar-thin mt-4 max-h-[360px] space-y-2.5 overflow-y-auto pr-1">
            <AnimatePresence initial={false}>
              {scanEvents.map((ev) => (
                <motion.div
                  key={ev.id}
                  layout
                  initial={{ opacity: 0, x: 60, scale: 0.96 }}
                  animate={{ opacity: 1, x: 0, scale: 1 }}
                  exit={{ opacity: 0, x: -40 }}
                  transition={{ type: "spring", stiffness: 280, damping: 26 }}
                  className={cn(
                    "flex items-center justify-between rounded-xl border p-3 text-xs",
                    ev.success
                      ? "border-white/5 bg-slate-900/70"
                      : "border-rose-500/25 bg-rose-950/30",
                  )}
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className={cn(
                        "flex h-7 w-7 items-center justify-center rounded-lg font-bold text-xs",
                        ev.success ? "bg-emerald-500/20 text-emerald-400" : "bg-rose-500/20 text-rose-400",
                      )}
                    >
                      {ev.success ? "✓" : "✗"}
                    </div>
                    <div>
                      <div className="font-bold text-white">
                        {ev.memberName} <span className="font-mono text-[10px] font-normal text-slate-400">({ev.memberId})</span>
                      </div>
                      <div className={cn("text-[10px]", ev.success ? "text-slate-400" : "text-rose-300")}>
                        {ev.success
                          ? `Confidence: ${ev.confidence.toFixed(1)}% • ${ev.plan}`
                          : "No vault match — intake required"}
                      </div>
                    </div>
                  </div>
                  <span
                    className={cn(
                      "font-mono text-[11px] font-semibold",
                      ev.success ? "text-emerald-400" : "text-rose-400",
                    )}
                  >
                    {ev.time}
                  </span>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
        <AuditStreamFooter />
      </div>
    </div>
  );
}
