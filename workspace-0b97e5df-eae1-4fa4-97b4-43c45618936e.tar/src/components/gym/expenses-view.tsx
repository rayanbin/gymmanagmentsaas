"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowDownLeft,
  ArrowUpRight,
  BadgeDollarSign,
  ChevronDown,
  PlusCircle,
  Receipt,
  Trash2,
  Lock,
  Zap,
  Wrench,
  Dumbbell,
  Wallet,
  Cloud,
  Check,
  LockKeyhole,
} from "lucide-react";
import { useGymStore } from "@/lib/gym/store";
import {
  RBAC,
  EXPENSE_CATEGORY_META,
  TOTAL_INCOME_MTD,
  type Expense,
  type ExpenseCategory,
} from "@/lib/gym/types";
import { WEEKLY_FLOWS } from "@/lib/gym/data";
import { GlassCard, staggerContainer, fadeSlideItem } from "./glass-card";
import { RippleButton } from "./ripple-button";
import { CountUp } from "./count-up";
import { formatMoney } from "@/lib/gym/data";
import { burstConfetti } from "@/lib/gym/confetti";
import { cn } from "@/lib/utils";

const CATEGORY_ICONS = {
  zap: Zap,
  wrench: Wrench,
  dumbbell: Dumbbell,
  wallet: Wallet,
  cloud: Cloud,
} as const;

export function ExpensesView() {
  const expenses = useGymStore((s) => s.expenses);
  const addExpense = useGymStore((s) => s.addExpense);
  const deleteExpense = useGymStore((s) => s.deleteExpense);
  const role = useGymStore((s) => s.role);
  const rbac = RBAC[role];

  const totalExpenses = useMemo(
    () => expenses.reduce((s, e) => s + e.amount, 0),
    [expenses],
  );
  const netProfit = TOTAL_INCOME_MTD - totalExpenses;
  const margin = ((netProfit / TOTAL_INCOME_MTD) * 100).toFixed(1);

  const [formOpen, setFormOpen] = useState(false);

  const handleAdd = (e: Omit<Expense, "id">) => {
    addExpense({ ...e, id: `EXP-${String(Date.now()).slice(-6)}` });
    setFormOpen(false);
    burstConfetti(0.5, 0.6);
  };

  return (
    <motion.div variants={staggerContainer} initial="hidden" animate="show" className="space-y-6">
      {/* header */}
      <motion.div variants={fadeSlideItem} className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="flex flex-wrap items-center gap-2 text-xl font-bold text-white">
            Financial Performance &amp; Expense Ledger
            <span className="rounded-full border border-amber-500/30 bg-amber-500/15 px-2.5 py-0.5 font-mono text-xs text-amber-400">
              P&amp;L Analysis
            </span>
          </h2>
          <p className="mt-1 text-xs text-slate-400">
            Maintain gym utilities, staff payroll, hardware amortizations, and calculate real Net Profit.
          </p>
        </div>
        {rbac.logExpense ? (
          <RippleButton
            variant="warning"
            onClick={() => setFormOpen((o) => !o)}
            aria-expanded={formOpen}
          >
            <PlusCircle className="h-4 w-4" />
            Log Gym Expense
            <motion.span animate={{ rotate: formOpen ? 180 : 0 }} className="inline-flex">
              <ChevronDown className="h-3.5 w-3.5" />
            </motion.span>
          </RippleButton>
        ) : (
          <span className="inline-flex items-center gap-2 rounded-xl border border-rose-500/25 bg-rose-500/10 px-4 py-2.5 text-xs font-semibold text-rose-300">
            <LockKeyhole className="h-4 w-4" /> Expense logging locked ({role === "manager" ? "Manager view" : "Staff view"})
          </span>
        )}
      </motion.div>

      {/* Add expense — accordion */}
      <AnimatePresence initial={false}>
        {formOpen && rbac.logExpense && (
          <motion.div
            key="acc"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="overflow-hidden"
          >
            <AddExpenseForm onAdd={handleAdd} onCancel={() => setFormOpen(false)} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* P&L summary cards */}
      <GlassCard variants={fadeSlideItem} hoverLift={false} className="border p-6 shadow-2xl">
        <div className="grid grid-cols-1 items-center gap-6 md:grid-cols-3">
          {/* income */}
          <div className="rounded-2xl border border-white/5 bg-navy-950/70 p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Total Income (MTD)
              </span>
              <div className="rounded-xl bg-emerald-500/15 p-2 text-emerald-400">
                <ArrowDownLeft className="h-4 w-4" />
              </div>
            </div>
            <div className="mt-2 font-mono text-2xl font-black text-white">
              <CountUp end={TOTAL_INCOME_MTD} prefix="$" formatting />
            </div>
            <div className="mt-1 flex items-center gap-1 text-[11px] font-medium text-emerald-400">
              <Check className="h-3.5 w-3.5" /> Subscriptions + Personal Trainer Cuts
            </div>
          </div>

          {/* expenses */}
          <div className="rounded-2xl border border-white/5 bg-navy-950/70 p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Total Expenses (MTD)
              </span>
              <div className="rounded-xl bg-rose-500/15 p-2 text-rose-400">
                <ArrowUpRight className="h-4 w-4" />
              </div>
            </div>
            <div className="mt-2 font-mono text-2xl font-black text-rose-400">
              <CountUp end={totalExpenses} prefix="$" formatting />
            </div>
            <div className="mt-1 flex items-center gap-1 text-[11px] text-slate-400">
              Utilities, maintenance, trainer payroll
            </div>
          </div>

          {/* net profit — color flips on sign */}
          <div
            className={cn(
              "rounded-2xl border-2 p-4 shadow-lg transition-colors duration-500",
              netProfit >= 0
                ? "border-emerald-500/40 bg-gradient-to-br from-emerald-950/40 via-slate-900/80 to-blue-950/40"
                : "border-rose-500/50 bg-gradient-to-br from-rose-950/40 via-slate-900/80 to-blue-950/40",
            )}
          >
            <div className="flex items-center justify-between">
              <span
                className={cn(
                  "text-xs font-extrabold uppercase tracking-wider",
                  netProfit >= 0 ? "text-emerald-400" : "text-rose-400",
                )}
              >
                Calculated Net Profit
              </span>
              <div
                className={cn(
                  "rounded-xl p-2",
                  netProfit >= 0 ? "bg-emerald-500/20 text-emerald-300" : "bg-rose-500/20 text-rose-300",
                )}
              >
                <BadgeDollarSign className="h-4 w-4" />
              </div>
            </div>
            <div
              className={cn(
                "mt-2 font-mono text-3xl font-black transition-colors duration-500",
                netProfit >= 0 ? "text-emerald-400" : "text-rose-400",
              )}
            >
              <CountUp end={netProfit} prefix="$" formatting />
            </div>
            <div className="mt-1 text-[11px] text-slate-300">
              Net Margin:{" "}
              <strong className={netProfit >= 0 ? "text-emerald-400" : "text-rose-400"}>
                {margin}%
              </strong>{" "}
              {netProfit >= 0 ? "(Exceptional Cash Flow)" : "(Deficit — cut spend)"}
            </div>
          </div>
        </div>
      </GlassCard>

      {/* Income vs Expense animated bars */}
      <GlassCard variants={fadeSlideItem} hoverLift={false} className="p-6">
        <div className="flex flex-col gap-2 border-b border-white/10 pb-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h3 className="text-sm font-bold text-white">Weekly Cash Flow — Income vs Expense</h3>
            <p className="text-xs text-slate-400">Hover a week to inspect the flow split</p>
          </div>
          <div className="flex items-center gap-4 font-mono text-xs">
            <span className="flex items-center gap-2 text-slate-300">
              <span className="h-3 w-3 rounded bg-emerald-400 shadow-sm shadow-emerald-400" /> Income
            </span>
            <span className="flex items-center gap-2 text-slate-300">
              <span className="h-3 w-3 rounded bg-rose-500 shadow-sm shadow-rose-500" /> Expense
            </span>
          </div>
        </div>
        <WeeklyBars />
      </GlassCard>

      {/* ledger table */}
      <GlassCard variants={fadeSlideItem} hoverLift={false} className="overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between border-b border-white/10 p-4">
          <h3 className="flex items-center gap-2 text-sm font-bold text-white">
            <Receipt className="h-4 w-4 text-amber-400" />
            Itemized Operational Disbursements
          </h3>
          <span className="font-mono text-xs text-slate-400">Real-time Balance Sheet</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-white/10 bg-slate-900/80 text-[10px] uppercase tracking-wider text-slate-400">
              <tr>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Category</th>
                <th className="px-4 py-3">Description / Vendor</th>
                <th className="px-4 py-3">Disbursed Amount</th>
                <th className="px-4 py-3 text-right">Audit Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              <AnimatePresence mode="popLayout">
                {expenses.map((e, i) => {
                  const meta = EXPENSE_CATEGORY_META[e.category];
                  const Icon = CATEGORY_ICONS[meta.icon as keyof typeof CATEGORY_ICONS];
                  return (
                    <motion.tr
                      key={e.id}
                      layout
                      initial={{ opacity: 0, y: 14 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -30 }}
                      transition={{ delay: i * 0.05, duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                      className="group transition hover:bg-slate-800/40"
                    >
                      <td className="px-4 py-3.5 font-mono text-slate-300">{e.date}</td>
                      <td className="px-4 py-3.5">
                        <span
                          className={cn(
                            "inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 font-semibold",
                            meta.bg,
                            meta.color,
                            meta.border,
                          )}
                        >
                          <Icon className="h-3.5 w-3.5 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:scale-125" />
                          {e.category}
                        </span>
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="font-semibold text-slate-200">{e.note}</div>
                        <div className="text-[10px] text-slate-500">{e.vendor}</div>
                      </td>
                      <td className="px-4 py-3.5 font-mono font-bold text-rose-400">
                        −{formatMoney(e.amount)}
                      </td>
                      <td className="px-4 py-3.5 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <span className="inline-flex items-center gap-1 rounded-full border border-emerald-500/25 bg-emerald-500/15 px-2 py-0.5 text-[10px] font-bold text-emerald-400">
                            <Check className="h-3 w-3" /> Audited
                          </span>
                          {rbac.logExpense && (
                            <button
                              onClick={() => deleteExpense(e.id)}
                              className="rounded-lg p-1.5 text-slate-500 opacity-0 transition group-hover:opacity-100 hover:bg-rose-500/15 hover:text-rose-400"
                              title="Delete entry (Owner)"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </motion.tr>
                  );
                })}
              </AnimatePresence>
            </tbody>
          </table>
        </div>
      </GlassCard>
    </motion.div>
  );
}

/* ───────────────────────── Weekly animated bars ───────────────────────── */

function WeeklyBars() {
  const max = Math.max(...WEEKLY_FLOWS.flatMap((w) => [w.income, w.expense])) * 1.12;

  return (
    <div className="mt-5 flex h-56 items-end justify-around gap-4 px-2">
      {WEEKLY_FLOWS.map((w, i) => (
        <div key={w.label} className="group flex h-full flex-1 flex-col items-center justify-end gap-2">
          {/* values on hover */}
          <div className="flex h-full w-full items-end justify-center gap-1.5">
            <motion.div
              initial={{ height: 0 }}
              animate={{ height: `${(w.income / max) * 100}%` }}
              transition={{ duration: 0.9, delay: 0.2 + i * 0.12, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ scale: 1.04 }}
              className="relative w-full max-w-[38px] rounded-t-lg bg-gradient-to-t from-emerald-600 to-emerald-400 shadow-lg shadow-emerald-500/20"
            >
              <span className="absolute -top-6 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-md bg-navy-950 px-1.5 py-0.5 font-mono text-[9px] font-bold text-emerald-300 opacity-0 shadow transition group-hover:opacity-100">
                {formatMoney(w.income)}
              </span>
            </motion.div>
            <motion.div
              initial={{ height: 0 }}
              animate={{ height: `${(w.expense / max) * 100}%` }}
              transition={{ duration: 0.9, delay: 0.32 + i * 0.12, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ scale: 1.04 }}
              className="relative w-full max-w-[38px] rounded-t-lg bg-gradient-to-t from-rose-600 to-rose-400 shadow-lg shadow-rose-500/20"
            >
              <span className="absolute -top-6 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-md bg-navy-950 px-1.5 py-0.5 font-mono text-[9px] font-bold text-rose-300 opacity-0 shadow transition group-hover:opacity-100">
                {formatMoney(w.expense)}
              </span>
            </motion.div>
          </div>
          <span className="font-mono text-xs text-slate-400">{w.label}</span>
        </div>
      ))}
    </div>
  );
}

/* ───────────────────────── Add expense accordion form ───────────────────────── */

function AddExpenseForm({
  onAdd,
  onCancel,
}: {
  onAdd: (e: Omit<Expense, "id">) => void;
  onCancel: () => void;
}) {
  const [category, setCategory] = useState<ExpenseCategory>("Utilities");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [note, setNote] = useState("");

  const submit = (ev: React.FormEvent) => {
    ev.preventDefault();
    const amt = parseFloat(amount);
    if (!amt || amt <= 0 || !note.trim()) return;
    onAdd({
      category,
      amount: amt,
      date,
      note: note.trim(),
      vendor: "Manual Entry",
    });
    setAmount("");
    setNote("");
  };

  const categories = Object.keys(EXPENSE_CATEGORY_META) as ExpenseCategory[];
  const catIcons = { Utilities: Zap, Equipment: Wrench, Supplements: Dumbbell, Payroll: Wallet, Software: Cloud };

  return (
    <motion.form
      initial={{ y: 18, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 18, opacity: 0 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      onSubmit={submit}
      className="glass-card space-y-4 rounded-2xl p-5 text-xs"
    >
      {/* bouncing category icons */}
      <div className="flex flex-wrap items-center gap-2">
        {categories.map((c) => {
          const Icon = catIcons[c];
          const meta = EXPENSE_CATEGORY_META[c];
          const active = category === c;
          return (
            <motion.button
              key={c}
              type="button"
              whileHover={{ y: -5, scale: 1.1 }}
              whileTap={{ scale: 0.92 }}
              transition={{ type: "spring", stiffness: 400, damping: 15 }}
              onClick={() => setCategory(c)}
              className={cn(
                "flex items-center gap-1.5 rounded-xl border px-3 py-2 font-semibold transition-colors",
                active ? meta.bg + " " + meta.color + " " + meta.border : "border-white/10 bg-slate-900/70 text-slate-400 hover:text-white",
              )}
            >
              <Icon className="h-4 w-4" />
              {c}
            </motion.button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div>
          <label className="mb-1 block font-medium text-slate-400">Amount ($ USD)</label>
          <input
            required
            type="number"
            step="0.01"
            min="0.01"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="glass-input w-full rounded-xl px-3.5 py-2.5 font-mono text-white placeholder-slate-500 focus:outline-none"
            placeholder="350.00"
          />
        </div>
        <div>
          <label className="mb-1 block font-medium text-slate-400">Date</label>
          <input
            required
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="glass-input w-full rounded-xl px-3.5 py-2.5 text-white [color-scheme:dark] focus:outline-none"
          />
        </div>
        <div>
          <label className="mb-1 block font-medium text-slate-400">Description / Vendor</label>
          <input
            required
            value={note}
            onChange={(e) => setNote(e.target.value)}
            className="glass-input w-full rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none"
            placeholder="e.g. Technogym cable pulley replace"
          />
        </div>
      </div>

      <div className="flex justify-end gap-3 border-t border-white/10 pt-3">
        <RippleButton variant="ghost" type="button" onClick={onCancel}>
          Cancel
        </RippleButton>
        <RippleButton variant="warning" type="submit">
          <PlusCircle className="h-4 w-4" />
          Record Disbursement
        </RippleButton>
      </div>
    </motion.form>
  );
}
