"use client";

import { motion, type HTMLMotionProps } from "framer-motion";
import { cn } from "@/lib/utils";

interface GlassCardProps extends HTMLMotionProps<"div"> {
  glowColor?: string; // css color for hover border glow
  hoverLift?: boolean;
  children?: React.ReactNode;
}

/**
 * Glassmorphic card with staggered fade-in on mount, scale 1.02 hover,
 * shadow-xl + accent border glow.
 */
export function GlassCard({
  glowColor = "rgba(59,130,246,0.35)",
  hoverLift = true,
  className,
  children,
  ...props
}: GlassCardProps) {
  return (
    <motion.div
      whileHover={
        hoverLift
          ? {
              scale: 1.02,
              y: -2,
              boxShadow: `0 15px 35px -5px rgba(0,0,0,0.6), 0 0 22px 2px ${glowColor}`,
              borderColor: glowColor,
            }
          : undefined
      }
      whileTap={hoverLift ? { scale: 0.995 } : undefined}
      transition={{ type: "spring", stiffness: 320, damping: 24 }}
      className={cn(
        "glass-card rounded-2xl relative",
        className,
      )}
      style={{ willChange: "transform" }}
      {...props}
    >
      {children}
    </motion.div>
  );
}

/** Standard stagger container variants — 0.1s delay between children. */
export const staggerContainer = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.1, delayChildren: 0.05 },
  },
};

/** Standard child fade+slide item variants. */
export const fadeSlideItem = {
  hidden: { opacity: 0, y: 18 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] as const },
  },
};
